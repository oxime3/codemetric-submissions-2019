package com.codemetrictech.firebaseserver;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class createToken {
    public createToken(){}

    public static class helper{
        // i)

        public static int mean(ArrayList<Integer> real_numbers){
            int result = 0;
            int length = real_numbers.size();

            for (int i=0; i<length; i++){
                result = result + real_numbers.get(i);
            }
            result = result/length;
            return result;
        }

        // ii)
        public static ArrayList<Integer> lower(ArrayList<Integer> real_numbers){
            ArrayList<Integer> result = new ArrayList<>();
            int length = real_numbers.size();
            int avg = mean(real_numbers);

            for (int i=0; i<length; i++){
                int number = real_numbers.get(i);
                if(number  < avg){
                    result.add(number);
                }

            }
            return result; }}

    public static void main(String[] args)  {

        ArrayList<Integer> tempList = new ArrayList<>();
        Scanner s = new Scanner(System.in);
        System.out.println("Enter 7 numbers one by one...");
        for (int i=0; i < 7; i++){
            System.out.println("Enter a real number: ");
            tempList.add(s.nextInt());
        }

        int avg = helper.mean(tempList);
        ArrayList<Integer> lower_than_avg = helper.lower(tempList);
        System.out.println("The average temperature is: " + avg
        + "/n The following readings were below average: ") ;

        for (int i=0; i < tempList.size(); i++){
            System.out.println(lower_than_avg.get(i));
        }




        FirebaseOptions options = null;
        FileInputStream serviceAccount = null;
        GoogleCredentials creds = null;

        try {
            serviceAccount = new FileInputStream("swenforums-4d059-firebase-adminsdk-gm6xj-9ae38c3cb9.json");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        try {
            creds = GoogleCredentials.fromStream(serviceAccount);
        } catch (IOException e) {
            e.printStackTrace();
        }


        options = new FirebaseOptions.Builder()
                .setCredentials(creds)
                .setDatabaseUrl("https://swenforums-4d059.firebaseio.com/")
                .build();

        FirebaseApp.initializeApp(options);


    }

    public static String exportToken(String Uid)  {

        main(null);
        String customToken = null;
        try {
            customToken = FirebaseAuth.getInstance().createCustomToken(Uid);
        } catch (FirebaseAuthException e) {
            e.printStackTrace();
        }
        return customToken;

    }

}
