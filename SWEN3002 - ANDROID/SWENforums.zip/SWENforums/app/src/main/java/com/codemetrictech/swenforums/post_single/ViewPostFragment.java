package com.codemetrictech.swenforums.post_single;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.view.menu.MenuBuilder;
import androidx.appcompat.view.menu.MenuPopupHelper;
import androidx.appcompat.widget.PopupMenu;
import androidx.appcompat.widget.ShareActionProvider;
import androidx.core.view.MenuItemCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.codemetrictech.swenforums.MainActivity;
import com.codemetrictech.swenforums.R;
import com.codemetrictech.swenforums.articles_list.Article;
import com.codemetrictech.swenforums.comments.CommentFragment;

import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;

import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.Objects;

public class ViewPostFragment extends Fragment {
    private Activity activity;

    private TextView post_title;
    private TextView post_category;
    private TextView post_body;

    private ShareActionProvider shareActionProvider;
    private BottomSheetBehavior bottomSheetBehavior;

    private FirebaseDatabase database = FirebaseDatabase.getInstance();
    private DatabaseReference reference = database.getReference("articles");
    private String id;
    private Query query;

    private Article post = new Article();

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof Activity)
            activity = (Activity) context;
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_view_post, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        id = getArguments().getString("ArticleID");
        query = reference.orderByChild("id").equalTo(id);
        retrieveFromDatabase(view);
    }

    private void retrieveFromDatabase(View view) {
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot singleSnapshot : dataSnapshot.getChildren()) {
                    post = singleSnapshot.getValue(Article.class);
                    initWidgets(view);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Snackbar.make(view, databaseError.toException().getMessage(), Snackbar.LENGTH_SHORT);
            }
        });
    }

    private void initWidgets(@NonNull View view) {
        post_title = view.findViewById(R.id.post_title);
        post_title.setText(post.getTitle());

        TextView post_author = view.findViewById(R.id.post_author);
        post_author.setText(post.getAuthor());

        TextView post_datetime = view.findViewById(R.id.post_datetime);
        post_datetime.setText(post.getDate());

        post_category = view.findViewById(R.id.post_category);
        post_category.setText(post.getCategory());

        post_body = view.findViewById(R.id.post_body);
        post_body.setText(post.getBody());
        post_body.setMovementMethod(new ScrollingMovementMethod());

        TextView post_views = view.findViewById(R.id.post_views);
        post_views.setText(String.valueOf(post.getViews()));

        View bottomSheet = view.findViewById(R.id.bottom_sheet);
        bottomSheetBehavior = BottomSheetBehavior.from(bottomSheet);
        bottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
        bottomSheetBehavior.setPeekHeight(10, true);
        bottomSheetBehavior.setFitToContents(false);

        TextView post_comments = view.findViewById(R.id.post_comments);
        post_comments.setOnClickListener((View v) -> {
            FragmentManager manager = ((MainActivity) activity).getSupportFragmentManager();
            if (manager.findFragmentById(R.id.bottom_sheet) == null){
                manager.beginTransaction()
                        .add(R.id.bottom_sheet, new CommentFragment(), "Comment Fragment")
                        .addToBackStack("Comment Fragment")
                        .commit();
            }

            bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
        });

        TextView post_actions = view.findViewById(R.id.post_actions);
        post_actions.setOnClickListener(v -> {
            PopupMenu popup = new PopupMenu(activity, view);
            popup.getMenuInflater().inflate(R.menu.post_actions, popup.getMenu());

            MenuItem item = popup.getMenu().findItem(R.id.action_share);
            shareActionProvider = (ShareActionProvider) MenuItemCompat.getActionProvider(item);

            popup.setOnMenuItemClickListener(menu_item -> {
                switch (menu_item.getItemId()) {
                    case R.id.action_edit:
                        Bundle edit = new Bundle();
                        edit.putString("id", id);
                        edit.putString("category", post_category.getText().toString());
                        edit.putString("title", post_title.getText().toString());
                        edit.putString("body", post_body.getText().toString());

                        Fragment fragment = new EditPostFragment();
                        fragment.setArguments(edit);
                        ((MainActivity) activity).switchFragment(fragment, "Edit Post Fragment");

                        break;

                    case R.id.action_delete:
                        new AlertDialog.Builder(activity)
                                .setTitle("Delete entry")
                                .setMessage("Are you sure you want to delete this entry?")
                                .setPositiveButton(android.R.string.yes, (dialog, which) -> removeFromDatabase(view))
                                .setNegativeButton(android.R.string.no, (dialog, which) -> {
                                    // do nothing
                                })
                                .setIcon(android.R.drawable.ic_dialog_alert)
                                .show();
                        break;

                    case R.id.action_report:
                        TextView textView = new TextView(activity);
                        textView.setTypeface(textView.getTypeface(), Typeface.BOLD);
                        textView.setText("SELECT REASON FOR REPORTING POST");
                        textView.setTextSize(TypedValue.COMPLEX_UNIT_SP,20);
                        textView.setGravity(Gravity.CENTER_VERTICAL | Gravity.CENTER_HORIZONTAL);

                        BottomSheetDialog dialog = new BottomSheetDialog(activity, R.style.BottomSheetDialogTheme);
                        dialog.setContentView(R.layout.dialog_report);

                        BottomSheetListView listView = dialog.findViewById(R.id.listViewBtmSheet);
                        Objects.requireNonNull(listView).addHeaderView(textView);
                        Objects.requireNonNull(listView).setOnItemClickListener((adapterView, view1, position, id) -> {
                            Toast.makeText(activity, new StringBuilder().append("Clicked item: ").append(position+1), Toast.LENGTH_LONG).show();
                        });

                        dialog.show();

                        break;

                    case R.id.action_share:
                        Intent share = new Intent(android.content.Intent.ACTION_SEND);
                        share.setType("text/plain");
                        share.putExtra(Intent.EXTRA_SUBJECT, post_title.getText());
                        share.putExtra(Intent.EXTRA_TEXT, "");
                        activity.startActivity(Intent.createChooser(share, "Share this post"));

                        break;
                }
                return true;
            });

            MenuPopupHelper menuHelper = new MenuPopupHelper(activity, (MenuBuilder) popup.getMenu(), view);
            menuHelper.setForceShowIcon(true);
            menuHelper.setGravity(Gravity.END);
            menuHelper.show();
        });
    }

    private void removeFromDatabase(View view) {
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot singleSnapshot : dataSnapshot.getChildren()) {
                    try {
                        singleSnapshot.getRef().removeValue();
                        Snackbar.make(view, "Post has successfully been deleted.", Snackbar.LENGTH_SHORT);
                        ((MainActivity) activity).getSupportFragmentManager().popBackStackImmediate();
                    } catch (Exception e) {
                        Snackbar.make(view, e.getMessage(), Snackbar.LENGTH_SHORT);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Snackbar.make(view, databaseError.toException().getMessage(), Snackbar.LENGTH_SHORT);
            }
        });
    }
}
