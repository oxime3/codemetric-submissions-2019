package com.codemetrictech.swenforums;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.codemetrictech.swenforums.utils.InputValidator;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;

public class RegisterFragment extends Fragment {
    private Activity activity;

    private EditText email;
    private EditText password;
    private ProgressBar progressCircular;
    private Button btn_register;
    private Button text_btn_home;

    private FirebaseAuth mAuth;
    private Boolean isValidPassword = false;
    private boolean isSigningUp = false;
    private boolean isNetworkDown = false;


    public static Fragment newInstance() { return new RegisterFragment(); }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof Activity)
            activity = (Activity) context;
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_register, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initWidgets(view);
    }

    private void initWidgets(View view) {
        email = view.findViewById(R.id.gist_email);
        email.setText(getArguments().getString("email"));

        password = view.findViewById(R.id.password);
        password.setOnFocusChangeListener((v, focused) -> {
            InputMethodManager keyboard = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
            if (focused)
                keyboard.showSoftInput(password, 0);
            else
                keyboard.hideSoftInputFromWindow(password.getWindowToken(), 0);
        });

        String passcode = password.getText().toString();
        if (!passcode.isEmpty()){
            isValidPassword = InputValidator.Companion.validatePassword(passcode);
            if (!isValidPassword){
                password.setError("Invalid Password.");
            }
        }

        progressCircular = view.findViewById(R.id.progress_circular);

        btn_register = view.findViewById(R.id.btn_register);
        btn_register.setOnClickListener(v -> {
            if (isValidPassword) {
                isSigningUp = true;
                isNetworkDown = false;
                updateUI();
                createFirebaseUser();
            }
        });

        text_btn_home = view.findViewById(R.id.text_btn_home);
        text_btn_home.setOnClickListener(v -> {
            new AlertDialog.Builder(activity)
                    .setTitle("Cancel Registration")
                    .setMessage("Are you sure you want to cancel registration?")
                    .setPositiveButton(android.R.string.yes, (dialog, which) -> ((HomeActivity) activity).clearBackStack())
                    .setNegativeButton(android.R.string.no, (dialog, which) -> {
                        // do nothing
                    })
                    .setIcon(android.R.drawable.ic_dialog_alert)
                    .show();

        });
    }

    private void createFirebaseUser() {
        mAuth = FirebaseAuth.getInstance();
        Task<AuthResult> authResultTask;

        authResultTask = mAuth.createUserWithEmailAndPassword(email.getText().toString(), password.getText().toString());
        executeTask(authResultTask);

        if (!authResultTask.isSuccessful() && !isNetworkDown) {
            authResultTask = mAuth.createUserWithEmailAndPassword(email.getText().toString(), password.getText().toString());
            executeTask(authResultTask);
        }

    }

    private void executeTask(Task<AuthResult> authResultTask){
        authResultTask.addOnSuccessListener(authResult -> {
            Snackbar.make(getView().findViewById(R.id.btn_register), "Registration successful.", Snackbar.LENGTH_SHORT).show();
        });

        authResultTask.addOnFailureListener(e -> {
            if (e.getMessage().contentEquals(getString(R.string.firebase_emailInUse_error))) {
                Snackbar.make(getView().findViewById(R.id.btn_register), "User account already exists. You will now be redirected to Login", Snackbar.LENGTH_SHORT).show();
                ((HomeActivity) activity).switchFragment(LoginFragment.newInstance());

            } else if (e.getMessage().contentEquals(getString(R.string.firebase_network_error))){
                Snackbar.make(getView().findViewById(R.id.btn_register), "Network error.", Snackbar.LENGTH_SHORT).show();
                isNetworkDown = true;

            } else {
                Snackbar.make(getView().findViewById(R.id.btn_register), "Unknown error.", Snackbar.LENGTH_SHORT).show();
            }

            isSigningUp = false;
            updateUI();
        });

        authResultTask.addOnCompleteListener(this::signUpOnFirebase);
    }

    private void signUpOnFirebase(Task<AuthResult> result){
        if (result.isSuccessful()) {
            addUsernameToUser(result.getResult().getUser());
        } else {
            isSigningUp = false;
            updateUI();
        }

    }

    private void addUsernameToUser(FirebaseUser user) {
        UserProfileChangeRequest profileUpdates = new UserProfileChangeRequest.Builder()
                .setDisplayName(getArguments().getString("user"))
                .build();

        user.updateProfile(profileUpdates).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                mAuth.signOut(); // Firebase signs a user in on creation; but we haven't signed in on our application
                ((HomeActivity) activity).switchFragment(LoginFragment.newInstance());
            }
        });
    }

    private void updateUI(){
        if (isSigningUp){
            btn_register.setText("PLEASE WAIT...");
            btn_register.setClickable(false);
            text_btn_home.setClickable(false);
            progressCircular.setVisibility(View.VISIBLE);
        } else {
            btn_register.setText("REGISTER");
            btn_register.setClickable(true);
            text_btn_home.setClickable(true);
            progressCircular.setVisibility(View.GONE);
        }
    }
}
