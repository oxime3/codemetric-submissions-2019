package com.codemetrictech.swenforums;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.codemetrictech.swenforums.articles_list.ArticleListActivity;
import com.codemetrictech.swenforums.categories.CategoriesFragment;
import com.codemetrictech.swenforums.post_single.ViewPostFragment;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private DrawerLayout drawer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        Intent intent = new Intent(this, HomeActivity.class);
        startActivityForResult(intent, 200);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 200) {
            if (resultCode == 100) {
                attachCategoriesFragment();
            } else {
                Snackbar.make(findViewById(R.id.drawer_layout), "Login Error.", Snackbar.LENGTH_SHORT);
            }
        }
    }

    private void attachCategoriesFragment() {
        getSupportFragmentManager().beginTransaction()
                .add(R.id.fragment_container, new CategoriesFragment(), "Categories Fragment")
                .addToBackStack("Categories Fragment")
                .commit();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);

        int resultCode = intent.getIntExtra("resultCode", 404);
        Bundle bundle = intent.getBundleExtra("bundle");
        String tag = intent.getStringExtra("tag");

        if (resultCode == 100) {
            Fragment fragment = new ViewPostFragment();
            fragment.setArguments(bundle);
            switchFragment(fragment, tag);
        } else {
            Snackbar.make(findViewById(R.id.drawer_layout), "Error launching View Post Fragment.", Snackbar.LENGTH_SHORT);
        }
    }

    @Override
    public void onBackPressed() {
        int backStackEntryCount = getSupportFragmentManager().getBackStackEntryCount();

        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);

        } else if (backStackEntryCount > 1) {
            if (getFragment(backStackEntryCount, 1).equals("View Post Fragment")) {
                if (getFragment(backStackEntryCount, 2).equals("Create Article Fragment")) {
                    clearBackStack();
                    attachCategoriesFragment();

                } else {
                    Intent intent = new Intent(MainActivity.this, ArticleListActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                    startActivity(intent);
                    getSupportFragmentManager().popBackStackImmediate();
                }

            } else {
                getSupportFragmentManager().popBackStackImmediate();
            }

        } else {
            moveTaskToBack(true);
        }

    }

    public void switchFragment(Fragment fragment, String tag) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, fragment, tag)
                .addToBackStack(tag)
                .commit();
    }

    public String getFragment(int count, int positionFromBack) {
        return getSupportFragmentManager().getBackStackEntryAt(count - positionFromBack).getName();
    }

    public void clearBackStack() {
        String name = getSupportFragmentManager().getBackStackEntryAt(0).getName();
        getSupportFragmentManager().popBackStackImmediate(name, FragmentManager.POP_BACK_STACK_INCLUSIVE);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        if (item.getItemId() == R.id.action_logout) {
            new AlertDialog.Builder(MainActivity.this)
                    .setTitle("Logout Confirmation")
                    .setMessage("Are you sure you want to logout?")
                    .setPositiveButton(android.R.string.yes, (dialog, which) -> {
                        FirebaseAuth.getInstance().signOut();

                        Intent intent = new Intent(this, HomeActivity.class);
                        startActivityForResult(intent, 200);
                    })
                    .setNegativeButton(android.R.string.no, (dialog, which) -> {
                        // do nothing
                    })
                    .setIcon(android.R.drawable.ic_dialog_alert)
                    .show();

            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_camera) {
            // Handle the camera action
        } else if (id == R.id.nav_gallery) {

        } else if (id == R.id.nav_slideshow) {

        } else if (id == R.id.nav_manage) {

        } else if (id == R.id.nav_share) {

        } else if (id == R.id.nav_send) {

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

}
