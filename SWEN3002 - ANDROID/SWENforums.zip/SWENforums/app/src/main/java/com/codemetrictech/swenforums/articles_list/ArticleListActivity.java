package com.codemetrictech.swenforums.articles_list;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.codemetrictech.swenforums.R;
import com.google.android.youtube.player.YouTubeBaseActivity;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


public class ArticleListActivity extends YouTubeBaseActivity {
    String TAG = "ArticleListActivity";

    RecyclerView recyclerView;
    ArticleAdapter adapter;
    YouTubePlayerView youtube_player;
    YouTubePlayer.OnInitializedListener mOnInitializesListener;

    public static List<Article> articleList = new ArrayList<>();

    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference databaseArticles = database.getReference("articles");

    private BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Log.d(TAG, "BroadcastOnReceive.");
            if(adapter != null){
                String count = intent.getStringExtra("count");
                adapter.viewHolder.commentslabel.setText(intent.getStringExtra(count));
            }

        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.articles_list);

        LocalBroadcastManager.getInstance(this)
                .registerReceiver(mReceiver, new IntentFilter("notify_comment_count"));
        Intent intent = getIntent();
        String category= intent.getStringExtra("category");

        ProgressBar loading_bar = findViewById(R.id.content_loading);
        loading_bar.setVisibility(View.VISIBLE);

        recyclerView = (RecyclerView) findViewById(R.id.recyclerV);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ArticleAdapter(this, articleList);
        recyclerView.setAdapter(adapter);


        youtube_player = (YouTubePlayerView) findViewById(R.id.youtube_player);
        mOnInitializesListener = new YouTubePlayer.OnInitializedListener() {
            @Override
            public void onInitializationSuccess(YouTubePlayer.Provider provider, YouTubePlayer youTubePlayer, boolean b) {
                String url;
                url = CategoryVideo.getUrl(category);
                youTubePlayer.loadVideo(url);
            }

            @Override
            public void onInitializationFailure(YouTubePlayer.Provider provider, YouTubeInitializationResult youTubeInitializationResult) {

            }
        };


        youtube_player.initialize(CategoryVideo.getApi_key(), mOnInitializesListener);
        TextView category_heading = (TextView) findViewById(R.id.category_heading);
        TextView postcount = (TextView) findViewById(R.id.postcount);
        postcount.setText("No. of posts: 0");



        databaseArticles.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot articleSnapshot: dataSnapshot.getChildren()) {
                    Article article = articleSnapshot.getValue(Article.class);

                    if (article.getCategory().equalsIgnoreCase(category)) {
                        articleList.add(article);
                        Log.d(TAG, "Adding article: " + article.getTitle());
                    }
                }
                postcount.setText("No. of posts: " + articleList.size());

                synchronized (adapter){
                    adapter.notifyDataSetChanged();
                    loading_bar.setVisibility(View.GONE);
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        category_heading.setText(category);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();

    }

}
