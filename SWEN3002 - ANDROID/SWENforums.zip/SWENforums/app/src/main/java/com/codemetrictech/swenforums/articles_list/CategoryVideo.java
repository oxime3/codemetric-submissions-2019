package com.codemetrictech.swenforums.articles_list;

public class CategoryVideo {

    public CategoryVideo(){

    }

    public static final String api_key = "AIzaSyDGcZbrj2ZIe8D2Xx_SnwaYa4o1y93pYKQ";

    public static String getApi_key(){
        return api_key;
    }

    public static String getUrl(String cat){

         String url = "Ur3nPfJA9UY";
        switch(cat) {
            case "Food and Drink" :
                url = "s1FaRCRgXHc";
            case "Laws" :
                url = "64X6My18LA8&t=212s";
            case "Social" :
                url = "J9LMSDcGIj4";
            case "Things To Do" :
                url = "tBNkeXmq4IQ";
            case "Travel" :
                url = "XBOXWwpKwP";
            case "Finance" :
                url = "XBOXWwpKwP";
            default : // Optional
                url = "Ur3nPfJA9UY";
        }


        return url;
    }
}
