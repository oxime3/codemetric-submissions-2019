package com.codemetrictech.swenforums.database;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;

public class DBHelper extends SQLiteOpenHelper {
    // Create Database
    public static final String DATABASE_NAME = "SWENFORUMS.db";

    // Create Articles Table
    public static final String ARTICLES_TABLE_NAME = "articles";
    public static final String ARTICLES_COLUMN_ID = "article_id";
    public static final String ARTICLES_COLUMN_TITLE = "article_title";
    public static final String ARTICLES_COLUMN_AUTHOR = "article_author";
    public static final String ARTICLES_COLUMN_DATETIME = "article_datetime";
    public static final String ARTICLES_COLUMN_CATEGORY = "article_category";
    public static final String ARTICLES_COLUMN_BODY = "article_body";
    public static final String ARTICLES_COLUMN_VIEWS = "article_views";
    public static final String ARTICLES_COLUMN_COMMENTS = "article_comments";

    private HashMap hp;

    public DBHelper(Context context) {
        super(context, DATABASE_NAME , null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(
                "create table articles " +
                "(article_id integer primary key autoincrement, " +
                        "article_title text, " +
                        "article_author text, " +
                        "article_datetime text, " +
                        "article_category text, " +
                        "article_body text," +
                        "article_views integer," +
                        "article_comments text)"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS articles");
        onCreate(db);
    }

    public boolean insertArticle (String article_title, String article_author, String article_datetime, String article_category, String article_body, Integer article_views, String article_comments) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(ARTICLES_COLUMN_TITLE, article_title);
        contentValues.put(ARTICLES_COLUMN_AUTHOR, article_author);
        contentValues.put(ARTICLES_COLUMN_DATETIME, article_datetime);
        contentValues.put(ARTICLES_COLUMN_CATEGORY, article_category);
        contentValues.put(ARTICLES_COLUMN_BODY, article_body);
        contentValues.put(ARTICLES_COLUMN_VIEWS, article_views);
        contentValues.put(ARTICLES_COLUMN_COMMENTS, article_comments);
        db.insert("articles", null, contentValues);
        return true;
    }

    public Cursor getData(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery( "select * from articles where id="+id+"", null );
    }

    public int numberOfRows(){
        SQLiteDatabase db = this.getReadableDatabase();
        return (int) DatabaseUtils.queryNumEntries(db, ARTICLES_TABLE_NAME);
    }

    public boolean updateArticle (Integer id, String article_title, String article_author, String article_datetime, String article_category, String article_body, Integer article_views, String article_comments) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(ARTICLES_COLUMN_TITLE, article_title);
        contentValues.put(ARTICLES_COLUMN_AUTHOR, article_author);
        contentValues.put(ARTICLES_COLUMN_DATETIME, article_datetime);
        contentValues.put(ARTICLES_COLUMN_CATEGORY, article_category);
        contentValues.put(ARTICLES_COLUMN_BODY, article_body);
        contentValues.put(ARTICLES_COLUMN_VIEWS, article_views);
        contentValues.put(ARTICLES_COLUMN_COMMENTS, article_comments);
        db.update("articles", contentValues, "id = ? ", new String[] { Integer.toString(id) } );
        return true;
    }

    public Integer deleteArticle (Integer id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete("articles",
                "id = ? ",
                new String[] { Integer.toString(id) });
    }

    public ArrayList<String> getAllArticles() {
        ArrayList<String> array_list = new ArrayList<>();

        //hp = new HashMap();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor =  db.rawQuery( "select * from articles", null );
        cursor.moveToFirst();

        while(!cursor.isAfterLast()){
            array_list.add(cursor.getString(cursor.getColumnIndex(ARTICLES_COLUMN_TITLE)));
            cursor.moveToNext();
        }

        cursor.close();

        return array_list;
    }
}
