package com.codemetrictech.swenforums.create_article;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.codemetrictech.swenforums.MainActivity;
import com.codemetrictech.swenforums.R;
import com.codemetrictech.swenforums.articles_list.Article;
import com.codemetrictech.swenforums.articles_list.ArticleListActivity;
import com.codemetrictech.swenforums.categories.CategoriesFragment;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.jetbrains.annotations.NotNull;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

//import android.support.v7.app.AppCompatActivity;
//import android.support.v7.widget.LinearLayoutManager;
//import android.support.v7.widget.RecyclerView;

public class CreateArticleFragment extends Fragment {
    Activity activity;

    EditText post_title, post_body;
    int articleviews = 0;
    Button cancelbutton, createbutton;
    Spinner selectcat;
    String selectedItemText;
    ArrayAdapter<CharSequence> adapter;
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference databaseArticles = database.getReference("articles");

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof Activity)
            activity = (Activity) context;
    }


    @Override
    public View onCreateView(@NotNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.create_article, container, false);
    }
    @Override
    public void onViewCreated(@NotNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);


        selectcat = view.findViewById(R.id.selectcat);
        post_title = view.findViewById(R.id.post_title);
        post_body = view.findViewById(R.id.post_body);
        cancelbutton = view.findViewById(R.id.cancelbutton);
        cancelbutton.setOnClickListener(new View.OnClickListener() {
            public void onClick (View v){
                FragmentManager fragmentManager = getFragmentManager();;
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.fragment_container, new CategoriesFragment(), "Categories Fragment");
                fragmentTransaction.addToBackStack("Categories Fragment");
                fragmentTransaction.commit();

            }
        });
        createbutton = view.findViewById(R.id.createbutton);
        createbutton.setOnClickListener(new View.OnClickListener(){
            public void onClick (View v){

                String articleid = addArticle();

                Bundle bundle = new Bundle();
                bundle.putString("ArticleID", articleid);

                Intent intent = new Intent(activity, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                intent.putExtra("resultCode", 100);
                intent.putExtra("bundle", bundle);
                intent.putExtra("tag", "View Post Fragment");

                activity.startActivity(intent);

            }
        });
        //code for spinner
        selectcat = (Spinner) view.findViewById(R.id.selectcat);
        adapter = ArrayAdapter.createFromResource(getContext(), R.array.category_names, android.R.layout.simple_spinner_dropdown_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        selectcat.setAdapter(adapter);

        selectcat.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedItemText = (String) parent.getItemAtPosition(position);
                Toast.makeText(getContext(), parent.getItemAtPosition(position) + " is selected", Toast.LENGTH_LONG).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


    }


    private String addArticle(){
        String articletitle = post_title.getText().toString();
        String articlebody = post_body.getText().toString();
        String articleauthor = FirebaseAuth.getInstance().getCurrentUser().getDisplayName();
        String articlecat = selectedItemText;

        if(!TextUtils.isEmpty(articletitle)){
            String id = databaseArticles.push().getKey();

            SimpleDateFormat sdf = new SimpleDateFormat("MMMM dd, yyyy");
            String articledate = sdf.format(new Date());

            Article article = new Article(id, articleauthor, articletitle, articlecat, articlebody, articleviews, articledate);
            databaseArticles.child(id).setValue(article);
            return id;
        }
        else{
            Toast.makeText(getContext(), "cannot have blank fields", Toast.LENGTH_LONG).show();
        }

        return "not added";
    }
}
