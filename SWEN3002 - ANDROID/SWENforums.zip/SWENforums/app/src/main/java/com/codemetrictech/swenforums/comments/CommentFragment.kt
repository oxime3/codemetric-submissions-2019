package com.codemetrictech.swenforums.comments

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import androidx.fragment.app.Fragment
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.codemetrictech.swenforums.R
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuth.getInstance
import com.google.firebase.database.*
import com.xwray.groupie.ExpandableGroup
import com.xwray.groupie.GroupAdapter
import com.xwray.groupie.ViewHolder
import kotlinx.android.synthetic.main.fragment_comment.*


class CommentFragment : Fragment() {
    private val TAG: String = "COMMENT FRAGMENT"

    private var groupAdapter = GroupAdapter<ViewHolder>()
    private lateinit var commentAddedListener: ChildEventListener
    private lateinit var replyAddedListener: ChildEventListener
    private var listener: OnFragmentInteractionListener? = null
    private var firebaseDatabase: DatabaseReference = FirebaseDatabase.getInstance().getReference("Comments")
    private var firebaseAuth: FirebaseAuth = getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {}
    }

    override fun onCreateView(
            inflater: LayoutInflater, container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_comment, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val keyboard = activity?.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager

        comment_input.setOnFocusChangeListener { it, hasFocus ->
            if (hasFocus) {
                post_button.visibility = View.VISIBLE
                cancel_button.visibility = View.VISIBLE
                keyboard.showSoftInput(it, 0)
            } else {
                post_button.visibility = View.GONE
                cancel_button.visibility = View.GONE
            }
        }
        post_button.setOnClickListener {
            if (comment_input.length() > 1) {
                createAndPushUserComment(comment_input.text.toString(), false)

                comment_input.setText("")
                cancel_button.callOnClick()
            } else {
                Snackbar.make(it, "Empty post.", Snackbar.LENGTH_SHORT).show()
            }
        }

        cancel_button.setOnClickListener {
            comment_input.clearFocus()

            keyboard.hideSoftInputFromWindow(it.windowToken, 0)

        }
        comment_RV.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = groupAdapter
        }

        groupAdapter.setOnItemClickListener { item, _ ->
            Log.d(TAG, item.toString())
        }

        inItCommentAddedListener()
    }

    fun setReplyAddedListener(dataRef: DatabaseReference, expandableComment: ExpandableComment) {
        Log.d(TAG, ": setReplyAddedListener()")

        this.replyAddedListener = object : ChildEventListener {

            override fun onChildAdded(replySnapshot: DataSnapshot, p1: String?) {
                Log.d(TAG, "onChildAdded~Reply")

                val replyComment = replySnapshot.getValue<Comment>(Comment::class.java)!!

                expandableComment.section.add(StaticComment(replyComment, expandableComment))
                expandableComment.notifyChanged()
            }

            override fun onCancelled(p0: DatabaseError) {
                Log.d("--REPLY LISTENER", p0.toString())
            }

            override fun onChildMoved(p0: DataSnapshot, p1: String?) {
                Log.d("--REPLY LISTENER", p0.toString())
            }

            override fun onChildChanged(p0: DataSnapshot, p1: String?) {
                Log.d("--REPLY LISTENER", p0.toString())
            }


            override fun onChildRemoved(p0: DataSnapshot) {
                Log.d("--REPLY LISTENER", p0.toString())
            }

        }
        dataRef.addChildEventListener(replyAddedListener)
    }

    private fun inItCommentAddedListener() {
        this.commentAddedListener = object : ChildEventListener {

            override fun onChildAdded(commentSnapshot: DataSnapshot, p1: String?) {
                Log.d(TAG, ": onChildAdded~Comment")

                val comment = commentSnapshot.getValue<Comment>(Comment::class.java)!!
                val repliesRef = firebaseDatabase.child(comment.commentUID).child("replies")

                val expandableComment = addExpandableComment(comment)
                setReplyAddedListener(repliesRef, expandableComment)
            }

            override fun onCancelled(databaseError: DatabaseError) {
                Log.d(TAG, "LoadComment: onCancelled ${databaseError.toException()}")
            }

            override fun onChildMoved(commentSnapshot: DataSnapshot, p1: String?) {
                Log.d(TAG, "LoadComment: onChildMoved ${commentSnapshot.toString()}")
            }

            override fun onChildChanged(commentSnapshot: DataSnapshot, p1: String?) {
                Log.d(TAG, "LoadComment: onChildChanged /n${commentSnapshot.toString()}")
                println("P!: " + p1)
            }


            override fun onChildRemoved(commentSnapshot: DataSnapshot) {
                Log.d(TAG, "LoadComment: onChildRemoved ${commentSnapshot.toString()}")
            }

        }
        firebaseDatabase.addChildEventListener(commentAddedListener)

    }


    fun addExpandableComment(comment: Comment): ExpandableComment {
        var expandableComment = ExpandableComment(comment, this)
        ExpandableGroup(expandableComment).apply {
            groupAdapter.add(this)
        }
        groupAdapter.getItemCount()
        notifyCommentCountChange(groupAdapter.itemCount)

        return expandableComment
    }

    fun createAndPushUserComment(comment_body: String, is_sub_comment: Boolean, parentComment: ExpandableComment? = null) {
        var user = firebaseAuth.currentUser

        if (user !== null) {
            val subCommentHashMap = HashMap<String, Comment>()

            if (!is_sub_comment) {
                val uID = firebaseDatabase.push().key!!
                val newComment = Comment(uID, user.displayName, comment_body, 0, 0, subCommentHashMap, "", is_sub_comment)

                firebaseDatabase.child(uID).setValue(newComment)
            } else {
                val UID = firebaseDatabase.child(parentComment?.comment?.commentUID!!).child("replies").push().key!!
                val newComment = Comment(UID, "Scott", comment_body, 0, 0, subCommentHashMap, "", is_sub_comment)

                firebaseDatabase.child(parentComment.comment.commentUID).child("replies").child(UID).setValue(newComment)

            }
        } else {
            Snackbar.make(view!!, "Please login to post", Snackbar.LENGTH_SHORT)
        }
    }

    private fun notifyCommentCountChange(newCnt: Int) {
        var intent = Intent("notify_comment_count")
        intent.putExtra("count", newCnt.toString())
        LocalBroadcastManager.getInstance(context!!).sendBroadcast(intent)
    }


    override fun onAttach(context: Context) {
        super.onAttach(context)
        if (context is OnFragmentInteractionListener) {
            listener = context
        } else {
            //throw RuntimeException(context.toString() + " must implement OnFragmentInteractionListener")
        }
    }

    override fun onDetach() {
        super.onDetach()
        listener = null
    }


    interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        fun onFragmentInteraction(uri: Uri)
    }

    companion object {
        @JvmStatic
        fun newInstance() =
                CommentFragment().apply {
                    arguments = Bundle().apply {

                    }
                }

    }
}
