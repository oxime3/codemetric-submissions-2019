package com.codemetrictech.swenforums.utils

class InputValidator {
    companion object {
        fun validateEmail(email: CharSequence): Boolean{
            return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()
        }

        fun validatePassword(password : CharSequence): Boolean{
            if (!password.contains("@G!C", false)){
                return false
            }
            return true
        }

        fun validateUsername(username : CharSequence): Boolean{
            if(!username.contains("UWI", true)){
                return false
            }
            return true
        }
    }
}