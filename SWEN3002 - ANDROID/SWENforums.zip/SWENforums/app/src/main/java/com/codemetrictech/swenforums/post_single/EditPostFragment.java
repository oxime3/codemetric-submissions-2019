package com.codemetrictech.swenforums.post_single;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.codemetrictech.swenforums.MainActivity;
import com.codemetrictech.swenforums.R;
import com.codemetrictech.swenforums.articles_list.Article;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;

public class EditPostFragment extends Fragment {
    private Activity activity;

    private FirebaseDatabase database = FirebaseDatabase.getInstance();
    private DatabaseReference reference = database.getReference("articles");
    private String id;
    private Query query;

    private String selectedItemText;
    private EditText article_title, article_body;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof Activity)
            activity = (Activity) context;
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_edit_post, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        id = getArguments().getString("id");
        query = reference.orderByChild("id").equalTo(id);

        String category = getArguments().getString("category");
        Spinner spinner_categories = view.findViewById(R.id.spinner_categories);
        spinner_categories.setSelection(Arrays.asList(getResources().getStringArray(R.array.category_names)).indexOf(category));
        spinner_categories.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedItemText = (String) parent.getItemAtPosition(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        article_title = view.findViewById(R.id.article_title);
        article_title.setText(getArguments().getString("title"));

        article_body = view.findViewById(R.id.article_body);
        article_body.setText(getArguments().getString("body"));

        Button btn_cancel = view.findViewById(R.id.cancel);
        btn_cancel.setOnClickListener(v -> ((MainActivity) activity).getSupportFragmentManager().popBackStackImmediate());

        Button btn_update = view.findViewById(R.id.update);
        btn_update.setOnClickListener(v -> updateDatabase(view));
    }

    private void updateDatabase(View view) {
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                boolean updateTime = false;

                for (DataSnapshot singleSnapshot : dataSnapshot.getChildren()) {
                    Article article = singleSnapshot.getValue(Article.class);
                    DatabaseReference post = reference.child(id);

                    String title = article_title.getText().toString();
                    String body = article_body.getText().toString();

                    if (TextUtils.isEmpty(title) || TextUtils.isEmpty(body)) {
                        Snackbar.make(view.findViewById(R.id.fragment_edit_post), "Fields cannot be blank.", Snackbar.LENGTH_SHORT);
                    }
                    else {
                        try {
                            if (!article.getCategory().equals(selectedItemText)) {
                                updateTime = true;
                                post.child("category").setValue(selectedItemText);
                            }

                            if (!article.getTitle().equals(title)) {
                                updateTime = true;
                                post.child("title").setValue(title);
                            }

                            if (!article.getBody().equals(body)) {
                                updateTime = true;
                                post.child("body").setValue(body);
                            }

                            if (updateTime) {
                                SimpleDateFormat sdf = new SimpleDateFormat("MMMM dd, yyyy");
                                post.child("date").setValue(sdf.format(new Date()));
                            }

                            Snackbar.make(view.findViewById(R.id.fragment_edit_post), "Post has successfully been updated.", Snackbar.LENGTH_SHORT);
                            ((MainActivity) activity).getSupportFragmentManager().popBackStackImmediate();

                        } catch (Exception e) {
                            Snackbar.make(view.findViewById(R.id.fragment_edit_post), e.getMessage(), Snackbar.LENGTH_SHORT);
                        }
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Snackbar.make(view.findViewById(R.id.fragment_edit_post), databaseError.toException().getMessage(), Snackbar.LENGTH_SHORT);
            }
        });
    }
}
