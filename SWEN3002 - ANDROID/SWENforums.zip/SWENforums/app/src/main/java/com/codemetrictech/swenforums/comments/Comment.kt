package com.codemetrictech.swenforums.comments

import android.util.Log
import java.text.DateFormat
import java.util.*
import kotlin.collections.HashMap

class Comment(
        val commentUID: String = "<UID>",
        val owner: String? = "<Owner>",
        var body: String = "<post>",
        var num_upvotes: Int = 0,
        var num_downvotes: Int = 0,
        var replies: HashMap<String, Comment> = HashMap(),
        var misuse_flags: String = "<flag>",
        var is_sub_comment: Boolean = false) {

    val dateStamp: String


    init {
        val calendar = Calendar.getInstance(Locale.ENGLISH)
        val format = DateFormat.getDateTimeInstance().format(calendar.time)

        dateStamp = format.toString()
        Log.d("-- Created Comment", dateStamp)
    }


    constructor(body: String, is_sub_comment: Boolean) : this() {
        this.body = body
        this.is_sub_comment = is_sub_comment
    }
}

