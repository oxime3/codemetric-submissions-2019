package com.codemetrictech.swenforums.comments

import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.codemetrictech.swenforums.R
import com.google.firebase.database.FirebaseDatabase
import com.xwray.groupie.Item
import com.xwray.groupie.Section
import com.xwray.groupie.ViewHolder
import kotlinx.android.synthetic.main.single_comment.view.*


open class StaticComment(val comment: Comment, val parent_Comment: ExpandableComment) : Item<ViewHolder>() {

    val section = Section()
    var fb = FirebaseDatabase.getInstance().reference

    override fun getLayout(): Int {
        return R.layout.single_comment
    }

    override fun bind(viewHolder: ViewHolder, position: Int) {
        val view_item = viewHolder.itemView
        var cardview = view_item.CardView_singleComment
        val layoutParams = cardview.getLayoutParams() as ViewGroup.MarginLayoutParams
        layoutParams.setMargins(80, 0, 20, -5)
        cardview.requestLayout()



        view_item.TextView_author.setText(comment.owner)
        view_item.TextView_date.setText(comment.dateStamp.toString())
        view_item.TextView_message.setText("@uwi180923 " + comment.body)
        view_item.TextView_numOfPraises.setText(comment.num_upvotes.toString())
        view_item.TextView_showReplies.visibility = View.GONE

        view_item.ImageButton_reply.setOnClickListener {
            parent_Comment.section.add(this@StaticComment)
            parent_Comment.notifyChanged()
        }

        view_item.ImageButton_reply.setOnClickListener {
            view_item.reply_inputfield.visibility = View.VISIBLE
            view_item.cancel_reply.visibility = View.VISIBLE
            view_item.post_reply.visibility = View.VISIBLE
        }

        view_item.post_reply.setOnClickListener {
            if (view_item.reply_inputfield.length() < 1) {
                Toast.makeText(parent_Comment.controllerFragment.context, "Post cannot be empty!", Toast.LENGTH_SHORT).show()
            } else {
                var text = view_item.reply_inputfield.text.toString()
                view_item.reply_inputfield.setText("")
                view_item.cancel_reply.callOnClick()
                var reply = parent_Comment.controllerFragment.createAndPushUserComment(text, true)
                var sub_comment = StaticComment(Comment(text, true), this.parent_Comment)

                parent_Comment.section.add(sub_comment)

                if (this.parent_Comment.section.itemCount < 2) {
                    view_item.TextView_showReplies.visibility = View.VISIBLE
                    parent_Comment.getExpandableGroup().add(section)
                }
                if (parent_Comment.getExpandableGroup().isExpanded == false) {
                    parent_Comment.getExpandableGroup().onToggleExpanded()
                }
                parent_Comment.notifyChanged()
            }
        }

        view_item.cancel_reply.setOnClickListener {
            view_item.reply_inputfield.setText("")
            view_item.reply_inputfield.visibility = View.GONE
            view_item.cancel_reply.visibility = View.GONE
            view_item.post_reply.visibility = View.GONE
        }

        view_item.TextView_showReplies.setOnClickListener {
            parent_Comment.getExpandableGroup().onToggleExpanded()
            parent_Comment.notifyChanged()
        }
    }


    override fun toString(): String {
        return this.comment.owner.toString()
    }
}