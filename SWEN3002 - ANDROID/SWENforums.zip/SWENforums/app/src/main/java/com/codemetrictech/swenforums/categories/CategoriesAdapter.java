package com.codemetrictech.swenforums.categories;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.codemetrictech.swenforums.articles_list.ArticleListActivity;
import com.codemetrictech.swenforums.create_article.CreateArticleFragment;
import com.codemetrictech.swenforums.MainActivity;
import com.codemetrictech.swenforums.R;

public class CategoriesAdapter extends RecyclerView.Adapter<CategoriesAdapter.CategoriesHolder> {
    private Activity activity;
    private List<CategoriesFragment.Category> list;
    private RecyclerView mRecyclerView;

    private int previousExpandedPosition = -1;
    private int currentExpandedPosition = -1;

    CategoriesAdapter(Activity activity, List<CategoriesFragment.Category> list) {
        this.activity = activity;
        this.list = list;
    }

    @Override
    public void onAttachedToRecyclerView(@NonNull RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
        mRecyclerView = recyclerView;
    }

    @NonNull
    @Override
    public CategoriesHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater
                .from(parent.getContext())
                .inflate(R.layout.item_category, parent, false);
        return new CategoriesHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CategoriesHolder holder, int position) {
        CategoriesFragment.Category category = list.get(position);

        holder.bind(category);

        final boolean isExpanded = position == currentExpandedPosition;

        holder.subItem.setVisibility(isExpanded ? View.VISIBLE : View.GONE);
        holder.itemView.setActivated(isExpanded);

        if (isExpanded) {previousExpandedPosition = position;}

        holder.name.setOnClickListener(v -> {
            mRecyclerView.smoothScrollToPosition(position);
            currentExpandedPosition = isExpanded ? -1 : position;
            notifyItemChanged(previousExpandedPosition);
            notifyItemChanged(position);
        });

        holder.background.setOnClickListener(v -> {
            mRecyclerView.smoothScrollToPosition(position);
            currentExpandedPosition = isExpanded ? -1 : position;
            notifyItemChanged(previousExpandedPosition);
            notifyItemChanged(position);
        });

        holder.sub_item_view.setOnClickListener(v -> {
            Intent intent = new Intent(activity, ArticleListActivity.class);
            intent.putExtra("host", MainActivity.class);
            intent.putExtra("category", holder.name.getText());
            activity.startActivity(intent);
        });

        holder.sub_item_create.setOnClickListener(v -> {
            Bundle bundle = new Bundle();
            bundle.putString("category", holder.name.getText().toString());

            Fragment fragment = new CreateArticleFragment();
            fragment.setArguments(bundle);

            ((MainActivity) activity).switchFragment(fragment, "Create Article Fragment");
        });
    }

    @Override
    public int getItemCount() {
        return list == null ? 0 : list.size();
    }

    class CategoriesHolder extends RecyclerView.ViewHolder {
        private ImageView background;
        private TextView name;
        private View subItem;
        private TextView sub_item_view;
        private TextView sub_item_create;

        CategoriesHolder(View itemView) {
            super(itemView);
            background = itemView.findViewById(R.id.item_background);
            name = itemView.findViewById(R.id.item_name);
            subItem = itemView.findViewById(R.id.sub_item);
            sub_item_view = itemView.findViewById(R.id.sub_item_view);
            sub_item_create = itemView.findViewById(R.id.sub_item_create);
        }

        private void bind(CategoriesFragment.Category category) {
            name.setText(category.getName());
            background.setBackgroundResource(category.getBackground());
        }

    }
}