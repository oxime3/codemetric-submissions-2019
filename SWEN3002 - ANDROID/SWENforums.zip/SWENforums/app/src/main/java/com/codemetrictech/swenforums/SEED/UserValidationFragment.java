package com.codemetrictech.swenforums.SEED;

import android.app.Activity;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;

import android.widget.ProgressBar;

import androidx.fragment.app.Fragment;

import androidx.annotation.NonNull;

import com.codemetrictech.swenforums.HomeActivity;
import com.codemetrictech.swenforums.LoginFragment;
import com.codemetrictech.swenforums.RegisterFragment;
import com.codemetrictech.swenforums.R;

import com.codemetrictech.swenforums.utils.InputValidator;
import com.google.android.material.snackbar.Snackbar;


import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import java.io.IOException;
import java.util.HashMap;

public class UserValidationFragment extends Fragment {
    private Activity activity;

    private EditText username;
    private EditText password;
    private ProgressBar progressBar;
    private Button btn_continue;
    private Button text_btn_login;

    private boolean isValidUsername = false;
    private boolean isValidPassword = false;
    private boolean isSigningIn = false;
    private boolean isNetworkDown = false;


    public static Fragment newInstance() { return new UserValidationFragment(); }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof Activity)
            activity = (Activity) context;
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_seed_user_validation, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initWidgets(view);
    }

    private void initWidgets(View view) {
        username = view.findViewById(R.id.seed_username);
        username.setOnFocusChangeListener((v, focused) -> {
            InputMethodManager keyboard = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
            if (focused)
                keyboard.showSoftInput(username, 0);
            else
                keyboard.hideSoftInputFromWindow(username.getWindowToken(), 0);

            String inputName = username.getText().toString();
            if (!inputName.isEmpty()){
                isValidUsername = InputValidator.Companion.validateUsername(inputName);
                if (!isValidUsername){
                    username.setError("Invalid username.");
                }
            }

        });

        password = view.findViewById(R.id.seed_password);
        password.setOnFocusChangeListener((v, focused) -> {
            InputMethodManager keyboard = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
            if (focused)
                keyboard.showSoftInput(password, 0);
            else
                keyboard.hideSoftInputFromWindow(password.getWindowToken(), 0);


            String inputPassword = password.getText().toString();
            if (!inputPassword.isEmpty()){
                isValidPassword = InputValidator.Companion.validatePassword(inputPassword);
                if (!isValidPassword){
                    password.setError("Invalid Password.");
                }
            }
        });

        progressBar = view.findViewById(R.id.progress_circular);

        btn_continue = view.findViewById(R.id.btn_continue);
        btn_continue.setOnClickListener(v -> {
            if (isValidUsername && isValidPassword) {
                isSigningIn = true;
                isNetworkDown = false;
                updateUI();
                new Login().execute();

            } else if (isNetworkDown) {
                Snackbar.make(view, "Please check your connection.", Snackbar.LENGTH_SHORT).show();

            } else {
                Snackbar.make(view, "Please check your form.", Snackbar.LENGTH_SHORT).show();
                username.requestFocus();
            }

        });

        text_btn_login = view.findViewById(R.id.text_btn_login);
        text_btn_login.setOnClickListener(v ->
                ((HomeActivity)activity).switchFragment(LoginFragment.newInstance()));
    }


    private void updateUI() {
        if (isSigningIn) {
            btn_continue.setText("PLEASE WAIT...");
            btn_continue.setClickable(false);
            text_btn_login.setClickable(false);
            progressBar.setVisibility(View.VISIBLE);
        } else {
            btn_continue.setText("CONTINUE");
            btn_continue.setClickable(true);
            text_btn_login.setClickable(true);
            progressBar.setVisibility(View.GONE);
        }
    }

    private void continueRegistration(String user, String email) {
        Bundle bundle = new Bundle();
        bundle.putString("user", user);
        bundle.putString("email", email);

        Fragment fragment = RegisterFragment.newInstance();
        fragment.setArguments(bundle);

        ((HomeActivity) activity).switchFragment(fragment);
    }

    private class Login extends AsyncTask<Void, Void, Void> {
        String USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36 OPR/58.0.3135.127";
        String url_login = "http://seed.gist-edu.cn/login/index.php";

        HashMap<String, String> cookies = new HashMap<>();
        HashMap<String, String> credentials = new HashMap<>();

        Boolean credentialsAreValid = false;
        String email = "";
        String user = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            activity.getCurrentFocus();
        }

        @Override
        protected Void doInBackground(Void... voids) {
            try {
                Connection.Response loginForm = Jsoup
                        .connect(url_login)
                        .method(Connection.Method.GET)
                        .userAgent(USER_AGENT)
                        .execute();

                cookies.putAll(loginForm.cookies());

                credentials.put("username", username.getText().toString());
                credentials.put("password", password.getText().toString());

                Connection.Response homepage = Jsoup
                        .connect(url_login)
                        .cookies(cookies)
                        .data(credentials)
                        .method(Connection.Method.POST)
                        .userAgent(USER_AGENT)
                        .execute();

                Document document = homepage.parse();

                if (!document.title().contains("Login to the site")) {
                    credentialsAreValid = true;
                    activity.runOnUiThread(() -> Snackbar.make(getView().findViewById(R.id.form_seed_login), "SEED Authentication Successful", Snackbar.LENGTH_SHORT).show());

                    user = document.select("div[class=logininfo]").select("a").first().text();

                    email = username.getText().toString().substring(3);
                    email += "@gist.edu.cn";
                }
                else {
                    activity.runOnUiThread(() -> Snackbar.make(getView().findViewById(R.id.form_seed_login), "Username or Password incorrect", Snackbar.LENGTH_SHORT).show());
                }
            }
            catch (IOException ioe) {
                isNetworkDown = true;
                activity.runOnUiThread(() -> Snackbar.make(getView().findViewById(R.id.form_seed_login), ioe.getMessage(), Snackbar.LENGTH_SHORT).show());
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);

            cookies.clear(); // Ends the session

            if (credentialsAreValid)
                continueRegistration(user, email);
            else {
                isSigningIn = false;
                updateUI();
                username.requestFocus();
            }
        }
    }

}
