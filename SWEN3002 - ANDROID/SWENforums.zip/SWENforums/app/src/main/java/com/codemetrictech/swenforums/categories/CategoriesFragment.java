package com.codemetrictech.swenforums.categories;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SimpleItemAnimator;

import com.codemetrictech.swenforums.MainActivity;
import com.codemetrictech.swenforums.R;

public class CategoriesFragment extends Fragment {
    private Activity activity;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof Activity)
            this.activity = (Activity) context;
    }

    @Override
    public View onCreateView(@NotNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_categories, container, false);
    }

    @Override
    public void onViewCreated(@NotNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        List<Category> Categories = new ArrayList<>();

        Categories.add(new Category("Food and Drink", R.drawable.food));
        Categories.add(new Category("Things To Do", R.drawable.activities));
        Categories.add(new Category("Laws", R.drawable.rules));
        Categories.add(new Category("Social", R.drawable.social));
        Categories.add(new Category("Finance", R.drawable.finance));
        Categories.add(new Category("Travel", R.drawable.travel));

        CategoriesAdapter adapter = new CategoriesAdapter(activity, Categories);

        RecyclerView recyclerView = view.findViewById(R.id.recview);

        ((SimpleItemAnimator) Objects.requireNonNull(recyclerView.getItemAnimator())).setSupportsChangeAnimations(false);

        recyclerView.setLayoutManager(new LinearLayoutManager(activity));
        recyclerView.setAdapter(adapter);
        recyclerView.setHasFixedSize(true);
    }

    public static class Category {
        private String name;
        private Integer background;

        // Parameterised Constructor
        Category(String name, Integer background) {
            this.name = name;
            this.background = background;
        }


        // Getters
        public String getName() {
            return name;
        }

        Integer getBackground() {
            return background;
        }

    }
}
