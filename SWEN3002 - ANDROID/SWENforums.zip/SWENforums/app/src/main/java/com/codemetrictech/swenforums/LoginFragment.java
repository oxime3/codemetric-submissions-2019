package com.codemetrictech.swenforums;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ProgressBar;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.codemetrictech.swenforums.SEED.UserValidationFragment;
import com.codemetrictech.swenforums.utils.InputValidator;
import com.codemetrictech.swenforums.utils.Preferences;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class LoginFragment extends Fragment {
    private Activity activity;

    private EditText email;
    private EditText password;
    private CheckBox checkBox;
    private ProgressBar progressBar;
    private Button btn_login;
    private Button text_btn_register;

    private FirebaseAuth mAuth;
    private Preferences.PrefController prefController = Preferences.PrefController;
    private boolean isValidEmail = false;
    private boolean isValidPassword = false;
    private boolean isSigningIn = false;
    private boolean isNetworkDown = false;

    public static Fragment newInstance() { return new LoginFragment(); }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof Activity)
            activity = (Activity) context;
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_login, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initWidgets(view);
        checkUserPreferences();
    }

    private void initWidgets(View view) {
        email = view.findViewById(R.id.email);
        email.setOnFocusChangeListener((v, focused) -> {
            InputMethodManager keyboard = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);

            if (focused)
                keyboard.showSoftInput(email, 0);
            else
                keyboard.hideSoftInputFromWindow(email.getWindowToken(), 0);

            String userEmail = email.getText().toString();
            if (!TextUtils.isEmpty(userEmail)) {
                isValidEmail = InputValidator.Companion.validateEmail(userEmail);
                if (!isValidEmail) {
                    email.setError("Invalid email.");
                }
            }
        });

        password = view.findViewById(R.id.password);
        password.setOnFocusChangeListener((v, focused) -> {
            InputMethodManager keyboard = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);

            if (focused)
                keyboard.showSoftInput(password, 0);
            else
                keyboard.hideSoftInputFromWindow(password.getWindowToken(), 0);

            String userPassword = password.getText().toString();

            if (!TextUtils.isEmpty(userPassword)){
                isValidPassword = InputValidator.Companion.validatePassword(userPassword);
                if (!isValidPassword){
                    password.setError("Invalid Password.");
                }
            }
        });

        progressBar = view.findViewById(R.id.progress_circular);

        checkBox = view.findViewById(R.id.cb_remember_me);
        checkBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked){
                prefController.setRememberMe(activity, true );
            } else {
                prefController.setRememberMe(activity,false );
            }
        });

        btn_login = view.findViewById(R.id.btn_login);
        btn_login.setOnClickListener(v -> {
            btn_login.requestFocus();
            password.clearFocus();
            if (isValidEmail && isValidPassword){
                isSigningIn = true;
                isNetworkDown = false;
                updateUI();
                initFirebase(view);
            } else {
                Snackbar.make(v, "Please check your form.", Snackbar.LENGTH_SHORT).show();
                isSigningIn = false;
                updateUI();

                if (!isValidEmail)
                    email.requestFocus();
                else
                    password.requestFocus();
            }

        });

        text_btn_register = view.findViewById(R.id.text_btn_register);
        text_btn_register.setOnClickListener(v ->
                ((HomeActivity)activity).switchFragment(UserValidationFragment.newInstance()));
    }

    private void checkUserPreferences() {
        if (prefController.getRememberMe(activity)) {
            String pref_email = prefController.getUserEmail(activity);
            isValidEmail = true;
            email.setText(pref_email);
            checkBox.setChecked(true);
        }
    }

    private void initFirebase(View view) {
        mAuth = FirebaseAuth.getInstance();
        Task<AuthResult> authResultTask;

        authResultTask = mAuth.signInWithEmailAndPassword(email.getText().toString(), password.getText().toString());
        executeTask(view, authResultTask);

        if (!authResultTask.isSuccessful() && !isNetworkDown) {
            authResultTask = mAuth.signInWithEmailAndPassword(email.getText().toString(), password.getText().toString());
            executeTask(view, authResultTask);
        }
    }

    private void executeTask(View view, Task<AuthResult> authResultTask){

        authResultTask.addOnSuccessListener(authResult -> {
            Snackbar.make(view, "Login successful.", Snackbar.LENGTH_SHORT).show();

        });

        authResultTask.addOnFailureListener(e -> {
            if (e.getMessage().contentEquals(getString(R.string.firebase_email_error))){
                email.setError(getString(R.string.bad_email_error_msg));
                isValidEmail = false;
                email.requestFocus();

            } else if (e.getMessage().contentEquals(getString(R.string.firebase_password_error))){
                password.setError(getString(R.string.erroneous_password_error_msg));
                isValidPassword = false;
                password.requestFocus();

            } else if(e.getMessage().contentEquals(getString(R.string.firebase_emailInUse_error))) {
                mAuth.signInWithEmailAndPassword(email.getText().toString(), password.getText().toString());

            } else if(e.getMessage().contentEquals(getString(R.string.firebase_network_error))){
                Snackbar.make(view, "Network error.", Snackbar.LENGTH_SHORT).show();
                isNetworkDown = true;

            } else {
                Snackbar.make(view, "Unknown error.", Snackbar.LENGTH_SHORT).show();
            }
        });

        authResultTask.addOnCompleteListener(this::signInToFireBase);
    }

    private void signInToFireBase(Task<AuthResult> result) {
        if (result.isSuccessful()) {
            Intent intent = new Intent();
            activity.setResult(100, intent);
            setUserPreferences();
            activity.finish();
        } else {
            isSigningIn = false;
            updateUI();
        }

    }

    private void setUserPreferences(){
        if (checkBox.isChecked()){
            prefController.setUserEmail(activity, email.getText().toString());
            email.clearFocus();
            password.requestFocus();
        } else {
            prefController.setUserEmail(activity, "");
        }
    }

    private void updateUI(){
        if (isSigningIn) {
            email.setEnabled(false);
            password.setEnabled(false);
            checkBox.setEnabled(false);
            btn_login.setText("PLEASE WAIT...");
            btn_login.setClickable(false);
            text_btn_register.setClickable(false);
            progressBar.setVisibility(View.VISIBLE);
        } else {
            email.setEnabled(true);
            password.setEnabled(true);
            checkBox.setEnabled(true);
            btn_login.setText("LOGIN");
            btn_login.setClickable(true);
            text_btn_register.setClickable(true);
            progressBar.setVisibility(View.GONE);
        }

    }

}
