package com.codemetrictech.swenforums.articles_list;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.codemetrictech.swenforums.MainActivity;
import com.codemetrictech.swenforums.R;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class ArticleAdapter extends RecyclerView.Adapter <ArticleAdapter.ArticleViewHolder> {
    private Context mContext;
    ArticleViewHolder viewHolder;
    private List<Article> articleList;
    public static int cmt_cnt = 13;

    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference databaseArticles = database.getReference("articles");

    ArticleAdapter(Activity hostActivity, List<Article> articleList) {
        this.mContext = hostActivity;
        this.articleList = articleList;
    }

    @NonNull
    @Override
    public ArticleViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mContext);
        View view = inflater.inflate(R.layout.individual_article, null);
        ArticleViewHolder holder = new ArticleViewHolder(view);
        this.viewHolder = holder;
        return holder;
    }



    @Override
    public void onBindViewHolder(@NonNull ArticleViewHolder holder, int position) {
        Article article = articleList.get(position);


        holder.articletitle.setText((article.getTitle()));
        holder.articlebody.setText(article.getBody());
        holder.viewslabel.setText(String.valueOf(article.getViews()));
        holder.commentslabel.setText(String.valueOf(cmt_cnt));
        holder.commentslabel.setOnClickListener(view -> {

        });
        holder.readmorebutton.setOnClickListener(view -> {
            databaseArticles.child(article.getId()).child("views").setValue(article.getViews() + 1);

            Bundle bundle = new Bundle();
            bundle.putString("ArticleID", article.getId());

            Intent intent = new Intent(mContext, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            intent.putExtra("resultCode", 100);
            intent.putExtra("bundle", bundle);
            intent.putExtra("tag", "View Post Fragment");

            mContext.startActivity(intent);
        });

    }

    @Override
    public int getItemCount() {
        return articleList.size();
    }

    class ArticleViewHolder extends RecyclerView.ViewHolder{

        TextView articletitle, articlebody, viewslabel, commentslabel;
        Button readmorebutton;

        ArticleViewHolder(View itemView) {
            super(itemView);

            articletitle = itemView.findViewById(R.id.articletitle);
            articlebody = itemView.findViewById(R.id.articlebody);
            readmorebutton = itemView.findViewById(R.id.readmorebutton);
            viewslabel = itemView.findViewById(R.id.viewslabel);
            commentslabel = itemView.findViewById(R.id.commentslabel);
        }
    }
}

