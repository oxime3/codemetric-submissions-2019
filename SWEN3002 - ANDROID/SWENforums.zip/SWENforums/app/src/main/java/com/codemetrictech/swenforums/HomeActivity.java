package com.codemetrictech.swenforums;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;

import com.codemetrictech.swenforums.SEED.UserValidationFragment;

public class HomeActivity extends FragmentActivity {
    Button home_btn_register;
    Button home_btn_login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        initWidgets();
    }

    private void initWidgets() {
        home_btn_register = findViewById(R.id.home_btn_register);
        home_btn_register.setOnClickListener(v -> switchFragment(UserValidationFragment.newInstance()));

        home_btn_login = findViewById(R.id.home_btn_login);
        home_btn_login.setOnClickListener(v -> switchFragment(LoginFragment.newInstance()));
    }

    public void switchFragment(Fragment fragment) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.home_container, fragment)
                .addToBackStack(null)
                .commit();
    }

    public void clearBackStack() {
        String name = getSupportFragmentManager().getBackStackEntryAt(0).getName();
        getSupportFragmentManager().popBackStackImmediate(name, FragmentManager.POP_BACK_STACK_INCLUSIVE);
    }
}
