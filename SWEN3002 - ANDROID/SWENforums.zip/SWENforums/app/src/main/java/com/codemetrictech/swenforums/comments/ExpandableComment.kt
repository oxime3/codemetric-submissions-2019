package com.codemetrictech.swenforums.comments

import android.util.Log
import android.view.View
import android.widget.Toast
import com.codemetrictech.swenforums.R
import com.xwray.groupie.*
import kotlinx.android.synthetic.main.single_comment.view.*


class ExpandableComment(val comment: Comment, val controllerFragment: CommentFragment) : Item<ViewHolder>(), ExpandableItem {
    private val TAG = "~~Expandable Comment"

    private lateinit var expandableGroup: ExpandableGroup
    private lateinit var viewHolder: ViewHolder

    val section = Section()


    override fun getLayout(): Int {
        return R.layout.single_comment
    }

    override fun notifyChanged() {
        super.notifyChanged()
        if (this.section.itemCount > 0) {
            this.viewHolder.itemView.TextView_showReplies.visibility = View.VISIBLE
        } else {
            this.viewHolder.itemView.TextView_showReplies.visibility = View.GONE
        }
        if (this.expandableGroup.isExpanded) {
            this.viewHolder.itemView.TextView_showReplies.text = "hide ${this.section.itemCount} comments"
        } else {
            this.viewHolder.itemView.TextView_showReplies.text = """show ${this.section.itemCount} comments"""
        }
        Log.d(TAG, "Finished notifyChanged()")
    }

    override fun bind(viewHolder: ViewHolder, position: Int) {
        this.viewHolder = viewHolder
        this.expandableGroup.add(section)

        val vItem = viewHolder.itemView

        if (this.comment.is_sub_comment) {
            vItem.setPadding(69, 0, 69, 0)
        } else {
            vItem.setPadding(8, 0, 8, 0)
        }

        vItem.TextView_author.text = comment.owner
        vItem.TextView_message.text = comment.body
        vItem.TextView_date.text = comment.dateStamp
        vItem.TextView_numOfPraises.text = comment.num_upvotes.toString()
//        vItem.downvotes_textView.text = comment.num_upvotes.toString()

        setOnClickListeners(vItem)

        notifyChanged()
        Log.d(TAG, "Bind complete.")
    }

    override fun setExpandableGroup(onToggleListener: ExpandableGroup) {
        expandableGroup = onToggleListener
    }

    fun getExpandableGroup(): ExpandableGroup {
        return this.expandableGroup
    }


    private fun setOnClickListeners(vItem: View) {

        vItem.post_reply.setOnClickListener {
            if (vItem.reply_inputfield.length() < 1) {
                Toast.makeText(controllerFragment.context, "Post cannot be empty!", Toast.LENGTH_SHORT).show()
            } else {
                val commentBody = vItem.reply_inputfield.text.toString()
                vItem.reply_inputfield.setText("")
                vItem.cancel_reply.callOnClick()

                //create new comment and push to database.
                controllerFragment.createAndPushUserComment(commentBody, true, this@ExpandableComment)

                if (!this.expandableGroup.isExpanded) {
                    this.expandableGroup.onToggleExpanded()
                }
                notifyChanged()
            }
            Log.d(TAG, "Posted reply.")
        }

        vItem.TextView_showReplies.setOnClickListener {
            this.expandableGroup.onToggleExpanded()
            notifyChanged()
        }

        vItem.cancel_reply.setOnClickListener {
            vItem.reply_inputfield.setText("")
            vItem.post_reply.visibility = View.GONE
            vItem.cancel_reply.visibility = View.GONE
            vItem.reply_inputfield.visibility = View.GONE
        }

        vItem.ImageButton_reply.setOnClickListener {
            vItem.post_reply.visibility = View.VISIBLE
            vItem.cancel_reply.visibility = View.VISIBLE
            vItem.reply_inputfield.visibility = View.VISIBLE
        }
    }
}