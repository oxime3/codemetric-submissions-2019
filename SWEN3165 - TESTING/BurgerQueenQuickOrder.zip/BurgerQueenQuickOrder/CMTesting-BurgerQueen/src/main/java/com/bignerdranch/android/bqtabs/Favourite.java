package com.bignerdranch.android.bqtabs;

public class Favourite {
    private int itemid;

    public Favourite(int itemid){
        this.itemid = itemid;
    }

    public int getItemid() {
        return itemid;
    }
}
