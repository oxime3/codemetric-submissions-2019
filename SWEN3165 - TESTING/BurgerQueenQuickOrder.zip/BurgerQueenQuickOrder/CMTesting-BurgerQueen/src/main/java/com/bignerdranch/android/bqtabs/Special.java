package com.bignerdranch.android.bqtabs;

public class Special {

    private int itemid;

    public Special(int itemid){
        this.itemid = itemid;
    }

    public int getItemid() {
        return itemid;
    }
}
