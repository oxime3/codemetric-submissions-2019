package com.bignerdranch.android.bqtabs

import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.click
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.matcher.ViewMatchers.hasDescendant
import androidx.test.espresso.matcher.ViewMatchers.withText
import com.bignerdranch.android.bqtabs.tests.RecyclerViewMatcher

class helper{

    companion object Helper {

        fun withRecyclerView(id:Int): RecyclerViewMatcher{
            return RecyclerViewMatcher(id)
        }

        fun withContentAtPosition(id:Int, position:Int, content:String){
            onView(withRecyclerView(id).atPosition(position))
                    .check(matches(hasDescendant(withText(content))))
        }

        fun scrollToAndClickItemAtPostion(recViewId:Int, position: Int){
            onView(withRecyclerView(recViewId).atPosition(position)).perform(click())
        }

    }


}