package com.bignerdranch.android.bqtabs.tests.steps;


import android.widget.EditText;

import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;

//import static android.support.test.espresso.Espresso.onData;
//import static android.support.test.espresso.Espresso.onView;
//import static android.support.test.espresso.action.ViewActions.clearText;
//import static android.support.test.espresso.action.ViewActions.click;
//import static android.support.test.espresso.action.ViewActions.closeSoftKeyboard;
//import static android.support.test.espresso.action.ViewActions.typeText;
//import static android.support.test.espresso.assertion.ViewAssertions.matches;
//import static android.support.test.espresso.matcher.PreferenceMatchers.withKey;
//import static android.support.test.espresso.matcher.PreferenceMatchers.withTitleText;
//import static android.support.test.espresso.matcher.RootMatchers.isDialog;
//import static android.support.test.espresso.matcher.ViewMatchers.hasErrorText;
//import static android.support.test.espresso.matcher.ViewMatchers.isDisplayed;
//import static android.support.test.espresso.matcher.ViewMatchers.withContentDescription;
//import static android.support.test.espresso.matcher.ViewMatchers.withId;
//import static android.support.test.espresso.matcher.ViewMatchers.withInputType;
//import static android.support.test.espresso.matcher.ViewMatchers.withResourceName;
//import static android.support.test.espresso.matcher.ViewMatchers.withTagKey;
//import static android.support.test.espresso.matcher.ViewMatchers.withTagValue;
//import static android.support.test.espresso.matcher.ViewMatchers.withText;
import static androidx.test.espresso.Espresso.onData;
import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.clearText;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.hasErrorText;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withResourceName;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.is;
//import android.support.test.espresso.matcher.PreferenceMatchers;

import androidx.test.espresso.action.TypeTextAction;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.filters.LargeTest;
import androidx.test.rule.ActivityTestRule;

import com.bignerdranch.android.bqtabs.Settings;

@RunWith(AndroidJUnit4.class)
@LargeTest
//@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class AccountTestSteps {

    @Rule
    public ActivityTestRule<Settings> mActivityRule = new ActivityTestRule<>(
            Settings.class);


    @Before
    public void setUp() throws Exception {
        //Before Test case execution
    }

    @Test
    public void test3HasWidgets() {
        onView(withText("Account")).perform(click());
        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        onView(withText("Change Username")).check(matches(isDisplayed()));
        onView(withText("Change Password")).check(matches(isDisplayed()));
        onView(withText("Change Email")).check(matches(isDisplayed()));
        onView(withText("Change Restaurant")).check(matches(isDisplayed()));
    }

    @Test
    public void test3SuccessfulEmailChange() {

//        EditTextPreference idpreference = (EditTextPreference) findPreference("id");
//        ListPreference rest= (ListPreference)findPreference("home_list");
//        EditTextPreference user = (EditTextPreference)findPreference("user");
//        EditTextPreference passwd = (EditTextPreference)findPreference("pswd");
//        EditTextPreference email = (EditTextPreference)findPreference("email");
        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        onView(withText("Account")).perform(click());
        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        onView(withText("Change Email")).perform(click());
        onView(withResourceName("edit")).perform(clearText());
        onView(withResourceName("edit")).perform(new TypeTextAction("misch@hotmail.com")).perform(closeSoftKeyboard());
        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        //onView(withId(R.id.submitButton)).perform(click());
        onView(withText("OK")).perform(click());
//        onView(withTagValue(email)).perform(typeText("mischka"));
//        onView(withId(R.id.loginpswrd)).perform(typeText("0000"));
    }

    @Test
    public void test3EmptyEmailChange() {

        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        onView(withText("Account")).perform(click());
        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        onView(withText("Change Email")).perform(click());
        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        //onView(withTitleText("Change Email")).perform(clearText());
        onView(withResourceName("edit")).perform(clearText()).perform(closeSoftKeyboard());
        //onView(withContentDescription("Change Email")).inRoot(isDialog()).perform(clearText()).perform(closeSoftKeyboard());
        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        //onView(withText("Change Email")).perform(clearText());
        //onView(withResourceName("email")).perform(clearText());
        //onView(withId(R.id.submitButton)).perform(click());
        onView(withText("OK")).perform(click());
        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        onView(withResourceName("edit")).check(matches(hasErrorText("Cannot be empty")));
        //error message "Username/Password Incorrect"
        // Should see animation
    }

    @Test
    public void test3InvalidEmailChange1() {

        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        onView(withText("Account")).perform(click());
        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        onView(withText("Change Email")).perform(click());
        onView(withResourceName("edit")).perform(clearText());
        onView(withResourceName("edit")).perform(new TypeTextAction("mischkahotmail.com")).perform(closeSoftKeyboard());
        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        //onView(withId(R.id.submitButton)).perform(click());
        onView(withText("OK")).perform(click());
        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        onView(withResourceName("edit")).check(matches(hasErrorText("Invalid Email")));

        //error message "Username/Password Incorrect"
        // Should see animation
    }

    @Test
    public void test3InvalidEmailChange2() {

        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        onView(withText("Account")).perform(click());
        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        onView(withText("Change Email")).perform(click());
        onView(withResourceName("edit")).perform(clearText());
        onView(withResourceName("edit")).perform(new TypeTextAction("mischka@hotmailcom")).perform(closeSoftKeyboard());
        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        //onView(withId(R.id.submitButton)).perform(click());
        onView(withText("OK")).perform(click());
        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        onView(withResourceName("edit")).check(matches(hasErrorText("Invalid Email")));

        //error message "Username/Password Incorrect"
        // Should see animation
    }

    @Test
    public void test3SuccessfulLocationChange() {

        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        onView(withText("Account")).perform(click());
        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        onView(withText("Change Restaurant")).perform(click());
        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //onView(withId(R.id.locationSpinner)).perform(click());
        // Select a country from the list
        onData(allOf(is(instanceOf(String.class)), is("Global 188, YuanQu HuXi, Wuzhong Qu, Suzhou"))).perform(click());
        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void test3SuccessfulPwChange() {

        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        onView(withText("Account")).perform(click());
        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        onView(withText("Change Password")).perform(click());
        onView(withResourceName("edit")).perform(clearText());
        onView(withResourceName("edit")).perform(new TypeTextAction("1234")).perform(closeSoftKeyboard());
        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        //onView(withId(R.id.submitButton)).perform(click());
        onView(withText("OK")).perform(click());
        //error message "Username/Password Incorrect"
        // Should see animation
    }

    @Test
    public void test3EmptyPwChange() {

        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        onView(withText("Account")).perform(click());
        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        onView(withText("Change Password")).perform(click());
        onView(withResourceName("edit")).perform(clearText());
        //onView(withId(R.id.submitButton)).perform(click());
        onView(withText("OK")).perform(click());
        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        onView(withResourceName("edit")).check(matches(hasErrorText("Cannot be empty")));

        //error message "Username/Password Incorrect"
        // Should see animation
    }

    @Test
    public void test3SuccessfulUsernameChange() {

        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        onView(withText("Account")).perform(click());
        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        onView(withText("Change Username")).perform(click());
        onView(withResourceName("edit")).perform(clearText());
        onView(withResourceName("edit")).perform(new TypeTextAction("misch")).perform(closeSoftKeyboard());
        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        //onView(withId(R.id.submitButton)).perform(click());
        onView(withText("OK")).perform(click());

        //error message "Username/Password Incorrect"
        // Should see animation
    }

    @Test
    public void test3EmptyUsernameChange() {

        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        onView(withText("Account")).perform(click());
        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        onView(withText("Change Username")).perform(click());
        onView(withResourceName("edit")).perform(clearText());
        //onView(withId(R.id.submitButton)).perform(click());
        onView(withText("OK")).perform(click());
        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        onView(withResourceName("edit")).check(matches(hasErrorText("Cannot be empty")));

        //error message "Username/Password Incorrect"
        // Should see animation
    }


    @After
    public void tearDown() throws Exception {
        //After Test case Execution
    }
}