package com.bignerdranch.android.bqtabs.tests.steps;

import android.app.Activity;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;

import androidx.fragment.app.Fragment;
import androidx.test.espresso.FailureHandler;
import androidx.test.espresso.matcher.ViewMatchers;
import androidx.test.rule.ActivityTestRule;

import com.bignerdranch.android.bqtabs.*;
import com.bignerdranch.android.bqtabs.R;

import cucumber.api.java.After;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.Espresso.setFailureHandler;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.typeText;
import com.bignerdranch.android.bqtabs.helper;

import org.hamcrest.Matcher;

import static androidx.test.espresso.assertion.ViewAssertions.doesNotExist;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isClickable;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withEffectiveVisibility;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

public class cartSteps {
    private final String TAG = "Cart Testing~";

    private final helper.Helper util = helper.Helper;


    private final ActivityTestRule navLauncher = new ActivityTestRule<>(navigation.class, false, false);
    private final ActivityTestRule loginLauncher = new ActivityTestRule<>(Login.class, false, false);
    private final ActivityTestRule homeLauncher = new ActivityTestRule<>(MainActivity.class, false, false);

@After
private void finishActivity() {
    if (navLauncher.getActivity() != null) {
        navLauncher.finishActivity();
    }
    if (loginLauncher.getActivity() != null) {
        navLauncher.finishActivity();
    }
    if (homeLauncher.getActivity() != null) {
        navLauncher.finishActivity();
    }
}

    @Given("I launch the application")
    public void iLaunchTheApplication() {
        homeLauncher.launchActivity(null);
    }

    @Given("I have launched the home tab")
    public void thatIHaveLaunchedTheApp() throws Exception{
        homeLauncher.launchActivity(null);
        assertNotNull(homeLauncher.getActivity());

        Log.d(TAG, "Application launched");
    }

    @When("I enter {string} as my Username.")
    public void iEnterAsMyUsername(String username) {
        onView(withId(R.id.loginusernme)).perform(typeText(username));
    }

    @And("I enter {string} as my password.")
    public void iEnterAsMyPassword(String password) {
        onView(withId(R.id.loginpswrd)).perform(typeText(password));

    }

    @And("I press the login button.")
    public void iPressTheLoginButton() {
        onView(withId(R.id.submitButton)).check(matches(isClickable()));

        onView(withId(R.id.submitButton)).perform(closeSoftKeyboard()).perform(click());
    }

    @When("I attempt to login as user {string} with password {string}.")
    public void iAttemptToLoginAsUserWithPassword(String username, String password) {
        iEnterAsMyUsername(username);
        iEnterAsMyPassword(password);
        iPressTheLoginButton();
    }

    @Given("I am logged into the app.")
    public void iAmLoggedIntoTheApp(){
    if(homeLauncher.getActivity() == null){
        homeLauncher.launchActivity(null);
    }
    assertNotNull(homeLauncher.getActivity());
    }



    @Given("a user named {string} exists.")
    public void a_user_named_exists(String string) {

        Log.d(TAG, "a_user_named_exists: ");
    }


    @And("I am signed in as that user.")
    public void iAmSignedInAsThatUser() {
    }


    @Given("that I am logged into account {string}.")
    public void that_I_am_logged_into_account(String string) {
        onView(withId(R.id.loginusernme)).perform(typeText("Oxime"));
        
    }

    @Given("I am on the {string} tab.")
    public void iAmOnTheTab(String tab_name) {
        int id = 0;
        switch(tab_name){
            case "burger":
                id = R.id.burger_recyclerview;
                break;
            case "sides" :
                id = R.id.sides_recyclerview;
                break;
            case "drinks":
                id = R.id.drink_recyclerview;
                break;
            case "dessert":
            default:
                id = R.id.burger_recyclerview;
                break;

        }
        onView(withId(id)).check(matches(isDisplayed()));

    }

    @Given("there are {int} BACON QUEEN orders in my cart.")
    public void there_are_BACON_QUEEN_orders_in_my_cart(Integer int1) {

        // Write code here that turns the phrase above into concrete actions
        System.out.println("It works.");
    }

    @When("I add  {int} BACON QUEEN orders of to my cart.")
    public void i_add_BACON_QUEEN_orders_of_to_my_cart(Integer int1) {
        // Write code here that turns the phrase above into concrete actions
        System.out.println("It works.");
    }

    @When("I click on the cart tab.")
    public void i_click_on_the_cart_tab() {
        // Write code here that turns the phrase above into concrete actions
        System.out.println("It works.");
    }

    @Then("I should see {int} BACON QUEEN orders in my cart.")
    public void i_should_see_BACON_QUEEN_orders_in_my_cart(Integer int1) {
        // Write code here that turns the phrase above into concrete actions
        System.out.println("It works.");
    }

    @Then("I take a screenshot.")
    public void i_take_a_screenshot() {
        // Write code here that turns the phrase above into concrete actions
        System.out.println("It works.");
    }

    @Given("there are {int} TRIPLE BURGER orders in my cart.")
    public void there_are_TRIPLE_BURGER_orders_in_my_cart(Integer int1) {
        // Write code here that turns the phrase above into concrete actions
        System.out.println("It works.");
    }

    @When("I add  {int} TRIPLE BURGER orders of to my cart.")
    public void i_add_TRIPLE_BURGER_orders_of_to_my_cart(Integer int1) {
        // Write code here that turns the phrase above into concrete actions
        System.out.println("It works.");
    }

    @Then("I should see {int} TRIPLE BURGER orders in my cart.")
    public void i_should_see_TRIPLE_BURGER_orders_in_my_cart(Integer int1) {
        // Write code here that turns the phrase above into concrete actions
        System.out.println("It works.");
    }

    @Given("there are {int} QUARTER POUND QUEEN orders in my cart.")
    public void there_are_QUARTER_POUND_QUEEN_orders_in_my_cart(Integer int1) {
        // Write code here that turns the phrase above into concrete actions
        System.out.println("It works.");
    }

    @When("I add  {int} QUARTER POUND QUEEN orders of to my cart.")
    public void i_add_QUARTER_POUND_QUEEN_orders_of_to_my_cart(Integer int1) {
        // Write code here that turns the phrase above into concrete actions
        System.out.println("It works.");
    }

    @Then("I should see {int} QUARTER POUND QUEEN orders in my cart.")
    public void i_should_see_QUARTER_POUND_QUEEN_orders_in_my_cart(Integer int1) {
        // Write code here that turns the phrase above into concrete actions
        System.out.println("It works.");
    }


    @When("I press the {string} order.")
    public void iPressTheOrder(String order) {
        final int RecViewId = R.id.burger_recyclerview;
        onView(util.withRecyclerView(RecViewId).atPosition(2)).perform(click());
        onView(withId(R.id.dialogBtnCart)).perform(click());
        homeLauncher.finishActivity();
        navLauncher.launchActivity(null);
        navigation nav = (navigation) navLauncher.getActivity();
        nav.setFragment(new OrderFragment(), "nav_cart");

        try {
            Thread.sleep(6000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }


    }

    @And("I see an order called {string}.")
    public void iSeeAnOrderCalled(String item_name) {
        onView(withText("TRIPLE BURGER")).check(matches(isDisplayed()));

    }


    @Then("the application should be launched.")
    public void theApplicationShouldBeLaunched() {
    assertNotNull(homeLauncher.getActivity());
    }

    @Then("I navigate to the {string} tab.")
    public void iNavigateToTheTab(String tab_string) {
        onView(withId(R.id.main_nav)).perform(click());
        //onView(withText(tab_string)).perform(click());

    }

    @And("my login attempt is successful.")
    public void myLoginAttemptIsSuccessful() {
        onView(withId(R.id.viewpager_id)).check(matches(isDisplayed()));
    }

    @Then("I should see the home page.")
    public void iShouldSeeTheHomePage() {
    iAmOnTheTab("burger");
    onView(withId(R.id.viewpager_id)).check(matches(isDisplayed()));

    }

    @And("the bottom navigation should be visible.")
    public void theBottomNavigationShouldBeVisible() {
        //onView(withId(R.id.main_nav)).check(matches(withEffectiveVisibility(ViewMatchers.Visibility.VISIBLE)));
        onView(withId(R.id.nav_home)).perform(click());
    }

    @Given("I have launched the app.")
    public void iHaveLaunchedTheApp() {
        if (loginLauncher.getActivity() == null){
            loginLauncher.launchActivity(null);
        }
        assertNotNull(loginLauncher.getActivity());
    }

    @Then("I should see {string} is now in my cart.")
    public void iShouldSeeTRIPLEBURGERIsNowInMyCart() throws Throwable {
        onView(withText("TRIPLE BURGER")).check(matches(isDisplayed()));
     }

    @Then("I should see <additional> {string} is now in my cart.")
    public void iShouldSeeAdditionalIsNowInMyCart(String arg0) {
        onView(withText("TRIPLE BURGER")).check(matches(isDisplayed()));

    }

    @And("I add <additional> <item> orders to my cart.")
    public void iAddAdditionalItemOrdersToMyCart() {
//        final int RecViewId = R.id.burger_recyclerview;
//        onView(util.withRecyclerView(RecViewId).atPosition(2)).perform(click());

        for(int i=0;i<3;i++){
            onView(withId(R.id.dialogBtnCart)).perform(click());
        }

        homeLauncher.finishActivity();
        navLauncher.launchActivity(null);
        navigation nav = (navigation) navLauncher.getActivity();
        nav.setFragment(new fragmentFavorites(), "nav_cart");
        onView(withId(R.id.viewpager_idorder)).check(matches(isDisplayed()));
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @And("I add {string} {string} orders to my cart.")
    public void iAddOrdersToMyCart(String arg0, String arg1) {
        int times = Integer.parseInt(arg0);
        for(int i=0;i<3;i++){
            onView(withId(R.id.dialogBtnCart)).perform(click());
        }

        homeLauncher.finishActivity();
        navLauncher.launchActivity(null);
        navigation nav = (navigation) navLauncher.getActivity();
        nav.setFragment(new fragmentFavorites(), "nav_cart");
        onView(withId(R.id.viewpager_idorder)).check(matches(isDisplayed()));
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }


    @Then("I should see {string} {string} is now in my cart.")
    public void iShouldSeeIsNowInMyCart(String arg0, String arg1) {
        //onView(withText("QUARTER POUND QUEEN")).check(matches(isDisplayed()));
        onView(withId(R.id.favorites_recyclerview)).check(matches(isDisplayed()));
    }

    @Given("I am in the cart tab")
    public void iAmInTheCartTab() {
        final int RecViewId = R.id.burger_recyclerview;
        onView(util.withRecyclerView(RecViewId).atPosition(2)).perform(click());
        onView(withId(R.id.dialogBtnCart)).perform(click());
        homeLauncher.finishActivity();
        navLauncher.launchActivity(null);
        navigation nav = (navigation) navLauncher.getActivity();
        nav.setFragment(new OrderFragment(), "nav_cart");
    }

    @And("I delete an item in my cart.")
    public void iDeleteAnItemInMyCart() {

    }

    @Then("the item should be deleted")
    public void theItemShouldBeDeleted() {
        onView(withText("BACON QUEEN")).check(matches(isDisplayed()));
    }
}

