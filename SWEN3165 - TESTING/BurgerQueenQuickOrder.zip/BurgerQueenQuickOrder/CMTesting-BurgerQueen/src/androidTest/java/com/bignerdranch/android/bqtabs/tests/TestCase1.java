package com.bignerdranch.android.bqtabs.tests;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@CucumberOptions(features = "features",
glue = "com.bignerdranch.android.bqtabs.tests.steps")

//@CucumberOptions(features = "features",
//        glue = "com.bignerdranch.android.bqtabs.tests.steps",
//        tags = "@jane")

@RunWith(Cucumber.class)
public class TestCase1 {
}
