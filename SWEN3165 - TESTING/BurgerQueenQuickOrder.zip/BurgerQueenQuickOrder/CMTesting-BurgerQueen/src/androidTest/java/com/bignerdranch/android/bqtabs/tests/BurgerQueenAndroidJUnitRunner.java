package com.bignerdranch.android.bqtabs.tests;

import cucumber.api.android.CucumberAndroidJUnitRunner;

public class BurgerQueenAndroidJUnitRunner extends CucumberAndroidJUnitRunner {

}
