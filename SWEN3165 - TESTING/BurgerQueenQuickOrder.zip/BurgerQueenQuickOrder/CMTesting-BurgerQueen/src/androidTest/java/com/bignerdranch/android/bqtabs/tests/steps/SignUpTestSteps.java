package com.bignerdranch.android.bqtabs.tests.steps;


import androidx.test.espresso.action.TypeTextAction;
import androidx.test.filters.LargeTest;
import androidx.test.rule.ActivityTestRule;

import com.bignerdranch.android.bqtabs.R;
import com.bignerdranch.android.bqtabs.SignUp;

import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.junit.runners.MethodSorters;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import static androidx.test.espresso.Espresso.onData;
import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.clearText;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.hasErrorText;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.hasToString;
import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.startsWith;


@RunWith(AndroidJUnit4.class)
@LargeTest
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class SignUpTestSteps {

    @Rule
    public ActivityTestRule<SignUp> mActivityRule = new ActivityTestRule<>(
            SignUp.class);


    @Before
    public void setUp() throws Exception {
        //Before Test case execution
    }

    @Test
    public void test1HasWidgets() {


        onView(withId(R.id.usernameId)).check(matches(isDisplayed()));
        onView(withId(R.id.useremail)).check(matches(isDisplayed()));
        onView(withId(R.id.userpassword)).check(matches(isDisplayed()));
        onView(withId(R.id.userConfrimPassword)).check(matches(isDisplayed()));
        onView(withId(R.id.locationSpinner)).check(matches(isDisplayed()));
        onView(withId(R.id.textlogin)).check(matches(isDisplayed()));
        onView(withId(R.id.submitButton)).check(matches(isDisplayed()));

    }

    @Test
    public void test1EnterValidCredentials() {


        onView(withId(R.id.usernameId)).perform(new TypeTextAction("mischka"));
        onView(withId(R.id.useremail)).perform(new TypeTextAction("mischka@hotmail.com"));
        onView(withId(R.id.userpassword)).perform(new TypeTextAction("0000")).perform(closeSoftKeyboard());
        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        onView(withId(R.id.userConfrimPassword)).perform(new TypeTextAction("0000")).perform(closeSoftKeyboard());
        //onView(withId(R.id.userConfrimPassword)).perform(closeSoftKeyboard());
        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        onView(withId(R.id.locationSpinner)).perform(click());
        // Select a country from the list
        onData(allOf(is(instanceOf(String.class)), is("#5, Quingshang Road, Suzhou"))).perform(click());

        // Check that the country label is updated with selected country
        //onView(withId(R.id.locationSpinner)).check(matches(withText("#5, Quingshang Road, Suzhou")));

        onView(withId(R.id.submitButton)).perform(click());
    }

    @Test
    public void test1EnterValidDuplicateCredentials() {


        onView(withId(R.id.usernameId)).perform(new TypeTextAction("mischka"));
        onView(withId(R.id.useremail)).perform(new TypeTextAction("mischka@hotmail.com"));
        onView(withId(R.id.userpassword)).perform(new TypeTextAction("0000")).perform(closeSoftKeyboard());
        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        onView(withId(R.id.userConfrimPassword)).perform(new TypeTextAction("0000")).perform(closeSoftKeyboard());
        //onView(withId(R.id.userConfrimPassword)).perform(closeSoftKeyboard());
        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        onView(withId(R.id.locationSpinner)).perform(click());
        // Select a country from the list
        onData(allOf(is(instanceOf(String.class)), is("#5, Quingshang Road, Suzhou"))).perform(click());

        // Check that the country label is updated with selected country
        //onView(withId(R.id.locationSpinner)).check(matches(withText("#5, Quingshang Road, Suzhou")));

        onView(withId(R.id.submitButton)).perform(click());
        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        onView(withId(R.id.userpassword)).check(matches(hasErrorText("User Already Exists")));
    }

    @Test
    public void test1EmptyFields() {

        onView(withId(R.id.usernameId)).perform(clearText());
        onView(withId(R.id.useremail)).perform(new TypeTextAction("mischka@hotmail.com"));
        onView(withId(R.id.useremail)).perform(closeSoftKeyboard());
        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

//        onView(withId(R.id.locationSpinner)).perform(click());
//        onData(allOf(is(instanceOf(String.class)), is("#5, Quingshang Road, Suzhou"))).perform(click());

        // Check that the country label is updated with selected country
       // onView(withId(R.id.locationSpinner)).check(matches(withText("#5, Quingshang Road, Suzhou")));

        onView(withId(R.id.submitButton)).perform(click());
        onView(withId(R.id.usernameId)).check(matches(hasErrorText("Cannot be empty")));
        onView(withId(R.id.useremail)).check(matches(hasErrorText("Cannot be empty")));
        onView(withId(R.id.userpassword)).check(matches(hasErrorText("Cannot be empty")));
        onView(withId(R.id.userConfrimPassword)).check(matches(hasErrorText("Cannot be empty")));

        //onView(withText("Invalid Username")).check(matches(isDisplayed()));
        //error for blank fields - can't have that with a db
    }

    @Test
    public void test1InvalidEmail() {

        onView(withId(R.id.usernameId)).perform(new TypeTextAction("mischka"));
        onView(withId(R.id.useremail)).perform(new TypeTextAction("mischka@hotmailcom"));
        onView(withId(R.id.userpassword)).perform(new TypeTextAction("0000")).perform(closeSoftKeyboard());
        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        onView(withId(R.id.userConfrimPassword)).perform(new TypeTextAction("0000")).perform(closeSoftKeyboard());
        //onView(withId(R.id.userConfrimPassword)).perform(closeSoftKeyboard());
        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        onView(withId(R.id.locationSpinner)).perform(click());
        // Select a country from the list
        onData(allOf(is(instanceOf(String.class)), is("#5, Quingshang Road, Suzhou"))).perform(click());

        // Check that the country label is updated with selected country
        //onView(withId(R.id.locationSpinner)).check(matches(withText("#5, Quingshang Road, Suzhou")));


        onView(withId(R.id.submitButton)).perform(click());
        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        onView(withId(R.id.useremail)).check(matches(hasErrorText("Invalid Email")));

        //onView(withText("Invalid Email")).check(matches(isDisplayed()));
        // error message "Invalid Email"
    }

    @Test
    public void test2InvalidEmail() {

        onView(withId(R.id.usernameId)).perform(new TypeTextAction("mischka"));
        onView(withId(R.id.useremail)).perform(new TypeTextAction("mischkahotmailcom"));
        onView(withId(R.id.userpassword)).perform(new TypeTextAction("0000")).perform(closeSoftKeyboard());
        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        onView(withId(R.id.userConfrimPassword)).perform(new TypeTextAction("0000")).perform(closeSoftKeyboard());
        //onView(withId(R.id.userConfrimPassword)).perform(closeSoftKeyboard());
        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        onView(withId(R.id.locationSpinner)).perform(click());
        // Select a country from the list
        onData(allOf(is(instanceOf(String.class)), is("#5, Quingshang Road, Suzhou"))).perform(click());

        // Check that the country label is updated with selected country
        //onView(withId(R.id.locationSpinner)).check(matches(withText("#5, Quingshang Road, Suzhou")));


        onView(withId(R.id.submitButton)).perform(click());
        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        onView(withId(R.id.useremail)).check(matches(hasErrorText("Invalid Email")));
        //onView(withText("Invalid Email")).check(matches(isDisplayed()));
        // error message "Invalid Email"
    }

    @Test
    public void test1InvalidPwConfirmation() {

        onView(withId(R.id.usernameId)).perform(new TypeTextAction("mischka"));
        onView(withId(R.id.useremail)).perform(new TypeTextAction("mischka@hotmail.com"));
        onView(withId(R.id.userpassword)).perform(new TypeTextAction("0000")).perform(closeSoftKeyboard());
        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        onView(withId(R.id.userConfrimPassword)).perform(new TypeTextAction("0001")).perform(closeSoftKeyboard());
        //onView(withId(R.id.userConfrimPassword)).perform(closeSoftKeyboard());
        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        onView(withId(R.id.locationSpinner)).perform(click());
        // Select a country from the list
        onData(allOf(is(instanceOf(String.class)), is("#5, Quingshang Road, Suzhou"))).perform(click());

        // Check that the country label is updated with selected country
        //onView(withId(R.id.locationSpinner)).check(matches(withText("#5, Quingshang Road, Suzhou")));


        onView(withId(R.id.submitButton)).perform(click());
        onView(withId(R.id.userpassword)).check(matches(hasErrorText("Password doesn't match")));
        onView(withId(R.id.userConfrimPassword)).check(matches(hasErrorText("Password doesn't match")));

        //onView(withText("Password doesn't match")).check(matches(isDisplayed()));

        //error message with "Password doesn't match"
    }

    @After
    public void tearDown() throws Exception {
        //After Test case Execution
    }
}