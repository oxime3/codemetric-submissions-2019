package com.bignerdranch.android.bqtabs.tests.steps;

import android.content.Intent;

import androidx.recyclerview.widget.RecyclerView;
import androidx.test.espresso.Espresso;
import androidx.test.espresso.contrib.RecyclerViewActions;
import androidx.test.espresso.matcher.ViewMatchers;
import androidx.test.rule.ActivityTestRule;

import com.bignerdranch.android.bqtabs.Login;
import com.bignerdranch.android.bqtabs.R;
import com.bignerdranch.android.bqtabs.tests.utils.Utils;
import com.bignerdranch.android.bqtabs.tests.utils.RecyclerViewAssertions;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.But;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.Espresso.openActionBarOverflowOrOptionsMenu;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.PreferenceMatchers.withKey;
import static androidx.test.espresso.matcher.ViewMatchers.hasDescendant;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withEffectiveVisibility;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static androidx.test.platform.app.InstrumentationRegistry.getInstrumentation;
import static com.bignerdranch.android.bqtabs.tests.utils.Utils.atPosition;
import static junit.framework.TestCase.assertNotNull;
import static org.hamcrest.CoreMatchers.allOf;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.not;


public class AddToFavouritesSteps {
    private String tab_title;

    private ActivityTestRule<Login> activityTestRule = new ActivityTestRule<>(Login.class);
    private Login activity;

    @Before("@add-to-favourites-feature")
    public void setUp() {
        activityTestRule.launchActivity(new Intent());
        activity = activityTestRule.getActivity();
    }

    @After("@add-to-favourites-feature")
    public void tearDown() {
        activityTestRule.finishActivity();
    }



    /***********************************************************************************************
     *  BACKGROUND                                                                                 *
     ***********************************************************************************************/

    @Given("^that I am a valid user$")
    public void iAmAValidUser() {
        //assertNotNull(activity);
        onView(withId(R.id.submitButton)).perform(click());
    }

    @And("^I am on Home$")
    public void iAmOnHome() {
        //onView(withId(R.id.main_nav)).perform(NavigationViewActions.navigateTo(R.id.nav_home));
        onView(withText(R.id.nav_home));
    }

    @When("^I click on the three vertical dots in the toolbar$")
    public void iClickOnTheThreeVerticalDotsInTheToolbar() {
        openActionBarOverflowOrOptionsMenu(getInstrumentation().getTargetContext());
    }

    @Then("^I click on the Settings option$")
    public void iClickOnTheSettingsOption() {
        onView(withText("Settings")).perform(click());
    }

    @Then("^I click on General$")
    public void iClickOnGeneral() {
        onView(withText("General")).perform(click());
    }



    /***********************************************************************************************
     *  REPEATED ACROSS SCENARIOS                                                                  *
     ***********************************************************************************************/

    @And("^that the Favourites switch is enabled (.*?)$")
    public void thatTheFavouritesSwitchIsEnabled(String state) {
        //"Enable Favourite"
        //16908352

        //onData(allOf(is(instanceOf(Preference.class)), withKey("prefkey"))).onChildView(withClassName(is(Switch.class.getName()))).perform(click());
/*
        onData(allOf(is(instanceOf(Preference.class)), withKey("Enable Favourite")))
                .onChildView(withClassName(is(Switch.class.getName())))
                .atPosition(1)
                .perform(click());
*/
        if (state.equals("disabled"))
            onView(withText("Enable Favourite")).perform(click());

    }

    @And("I return to Home")
    public void iReturnToHome() {
        Espresso.pressBack();
        Espresso.pressBack();
    }

    @When("^I click on the (.*?) tab$")
    public void iClickOnTheInsertTitleHereTab(String title) {
        tab_title = title;
        onView(withId(R.id.tablayout_id)).perform(Utils.selectTabAtPosition(tab_title));
    }

    @Then("^I click on the (.*?) viewholder$")
    public void iClickOnTheItemViewHolder(String item) {

        onView(withId(Utils.returnValue(tab_title, "id")))
                .perform(RecyclerViewActions.actionOnItem(
                        hasDescendant(withText(item)),
                        click()));

    }

    @Then("I add (.*?) which is at position (.*?) to my favourites")
    public void iAddItemToMyFavourites(String item, int position) {
        onView(withId(Utils.returnValue(tab_title, "id")))
                .perform(RecyclerViewActions
                        .actionOnItemAtPosition(position,
                                Utils.clickChildViewWithId(R.id.rFavButton)));
    }



    @Then("I click on the item at position (.*?)")
    public void iClickOnItemWhichIsAtPositionPosition(int position) {
        onView(withId(Utils.returnValue(tab_title, "id")))
                .perform(RecyclerViewActions.actionOnItemAtPosition(position, click()));

    }

    @And("^I click on the Add to Favourites button in the dialog$")
    public void iClickOnTheAddToFavouritesButtonInTheDialog() {
        onView(withId(R.id.dialogBtnFav)).perform(click());
        Espresso.pressBack();

    }

    @When("^I click on Favourites on the Bottom Navigation Bar$")
    public void iClickOnFavouritesOnTheBottomNavigationBar() {
        //onView(withId(R.id.main_nav)).perform(NavigationViewActions.navigateTo(R.id.newfavorites));
        onView(withId(R.id.newfavorites));
    }

    /***********************************************************************************************
     *  UNIQUE TO SCENARIO 1                                                                       *
     ***********************************************************************************************/

    @Then("^I should see (.*?) in my list of favourites$")
    public void iShouldSeeInsertItemHereInMyListOfFavourites(String item) {

        onView(withId(Utils.returnValue(tab_title, "id")))
                .check(RecyclerViewAssertions.withRowContaining(withText(item)));

    }


    /***********************************************************************************************
     *  UNIQUE TO SCENARIO 2                                                                       *
     ***********************************************************************************************/

    @Then("^I should not see (.*?) in my list of favourites$")
    public void iShouldNotSeeItemInMyListOfFavourites(String item) {
        onView(withId(R.id.favorites_recyclerview))
                .check(matches(not(RecyclerViewAssertions.withRowContaining(withText(item)))));

    }


    /***********************************************************************************************
     *  UNIQUE TO SCENARIO 3                                                                       *
     ***********************************************************************************************/

    @Given("^that the Favourites switch is disabled (.*?)$")
    public void thatTheFavouritesSwitchIsDisabled(String state) {
        if (state.equals("enabled"))
            onView(withText("Enable Favourite")).perform(click());
    }

    @Then("^I should not see the Add To Favourites button$")
    public void iShouldNotSeeTheAddToFavouritesButton() {
        onView(withId(R.id.newfavorites))
                .check(matches(not(withEffectiveVisibility(ViewMatchers.Visibility.VISIBLE))));
    }

    @And("^the Bottom Navigation Bar should not display Favourites$")
    public void theBottomNavigationBarShouldNotDisplayFavourites() {
        onView(withId(R.id.newfavorites))
                .check(matches(not(withEffectiveVisibility(ViewMatchers.Visibility.VISIBLE))));
    }

    @But("I see (.*?) in my list of favourites")
    public void iSeeItemInMyListOfFavourites(String item) {
        onView(withId(R.id.favorites_recyclerview))
                .check(RecyclerViewAssertions.withRowContaining(withText(item)));
    }
}
