package com.bignerdranch.android.bqtabs.tests.steps;

import android.content.Intent;

import androidx.test.espresso.contrib.RecyclerViewActions;
import androidx.test.rule.ActivityTestRule;

import com.bignerdranch.android.bqtabs.Login;
import com.bignerdranch.android.bqtabs.R;
import com.bignerdranch.android.bqtabs.tests.utils.RecyclerViewAssertions;
import com.bignerdranch.android.bqtabs.tests.utils.Utils;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.matcher.ViewMatchers.hasDescendant;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static junit.framework.TestCase.assertNotNull;

public class RemoveFromFavouritesSteps {
    private ActivityTestRule<Login> activityTestRule = new ActivityTestRule<>(Login.class);
    private Login activity;

    @Before("@remove-from-favourites-feature")
    public void setUp() {
        activityTestRule.launchActivity(new Intent());
        activity = activityTestRule.getActivity();
    }

    @After("@remove-from-favourites-feature")
    public void tearDown() {
        activityTestRule.finishActivity();
    }

    /***********************************************************************************************
     *  BACKGROUND                                                                                 *
     ***********************************************************************************************/

    @And("^I am on Favourites$")
    public void iAmOnFavourites() {
        onView(withText(R.id.newfavorites));
    }


    /***********************************************************************************************
     *  SCENARIO
     ***********************************************************************************************/

    @When("^I click on the Remove from Favourites button on (.*?)$")
    public void iClickOnTheRemoveFromFavouritesButtonOnItem(String item) {
        onView(withId(R.id.favorites_recyclerview))
                .perform(RecyclerViewActions.actionOnItem(hasDescendant(withText(item)),
                        Utils.clickChildViewWithId(R.id.rDeleteButton)));
    }

    @Then("I should no longer see (.*?) in my favourites")
    public void iShouldNoLongerSeeItemInMyFavourites(String item) {
        onView(withId(R.id.favorites_recyclerview))
                .check(RecyclerViewAssertions.withRowContaining(withText(item)));
    }
}
