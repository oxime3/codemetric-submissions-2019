package com.bignerdranch.android.bqtabs.tests.steps;



import androidx.test.espresso.action.TypeTextAction;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.filters.LargeTest;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.rule.ActivityTestRule;
import androidx.test.uiautomator.UiDevice;

import com.bignerdranch.android.bqtabs.Login;
import com.bignerdranch.android.bqtabs.R;

import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;

import static androidx.test.espresso.Espresso.onData;
import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.clearText;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.hasErrorText;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withResourceName;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.is;


@RunWith(AndroidJUnit4.class)
@LargeTest
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class LoginTestSteps {

    @Rule
    public ActivityTestRule<Login> mActivityRule = new ActivityTestRule<>(
            Login.class);


    @Before
    public void setUp() throws Exception {
        //Before Test case execution
    }

    @Test
    public void test2HasWidgets() {

        onView(withId(R.id.textlogin)).check(matches(isDisplayed()));
        onView(withId(R.id.loginusernme)).check(matches(isDisplayed()));
        onView(withId(R.id.loginpswrd)).check(matches(isDisplayed()));
        onView(withId(R.id.submitButton)).check(matches(isDisplayed()));
    }

    @Test
    public void test2SuccessfulLogin() {

        onView(withId(R.id.loginusernme)).perform(new TypeTextAction("mischka")).perform(closeSoftKeyboard());
        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        onView(withId(R.id.loginpswrd)).perform(new TypeTextAction("0000")).perform(closeSoftKeyboard());
        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        onView(withId(R.id.submitButton)).perform(click());
    }

    @Test
    public void test2EmptyLogin() {

        onView(withId(R.id.loginusernme)).perform(clearText()).perform(closeSoftKeyboard());
        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        onView(withId(R.id.loginpswrd)).perform(clearText()).perform(closeSoftKeyboard());
        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        onView(withId(R.id.submitButton)).perform(click());
        onView(withId(R.id.loginusernme)).check(matches(hasErrorText("Cannot be empty")));
        onView(withId(R.id.loginpswrd)).check(matches(hasErrorText("Cannot be empty")));
    }

    @Test
    public void test2WrongPwLogin() {

        onView(withId(R.id.loginusernme)).perform(new TypeTextAction("mischka")).perform(closeSoftKeyboard());
        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        onView(withId(R.id.loginpswrd)).perform(new TypeTextAction("0001")).perform(closeSoftKeyboard());
        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        onView(withId(R.id.submitButton)).perform(click());

        onView(withId(R.id.loginpswrd)).check(matches(hasErrorText("Username/Password Incorrect")));
        //error message "Username/Password Incorrect"
        // Should see animation
    }

    @Test
    public void test2WrongUsernameLogin() {

        onView(withId(R.id.loginusernme)).perform(new TypeTextAction("misch")).perform(closeSoftKeyboard());
        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        onView(withId(R.id.loginpswrd)).perform(new TypeTextAction("0000")).perform(closeSoftKeyboard());
        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        onView(withId(R.id.submitButton)).perform(click());

        onView(withId(R.id.loginusernme)).check(matches(hasErrorText("Username/Password Incorrect")));

        //error message "Username/Password Incorrect"
        // Should see animation
    }

    @Test
    public void test2BothCredentialsWrongLogin() {

        onView(withId(R.id.loginusernme)).perform(new TypeTextAction("misch")).perform(closeSoftKeyboard());
        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        onView(withId(R.id.loginpswrd)).perform(new TypeTextAction("0001")).perform(closeSoftKeyboard());
        try {
            Thread.sleep(350);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        onView(withId(R.id.submitButton)).perform(click());

        onView(withId(R.id.loginusernme)).check(matches(hasErrorText("Username/Password Incorrect")));
        onView(withId(R.id.loginpswrd)).check(matches(hasErrorText("Username/Password Incorrect")));

        //error message "Username/Password Incorrect"
        // Should see animation
    }

    @Test
    public void test2Logout() {

        test2SuccessfulLogin();

        try {
            Thread.sleep(450);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        UiDevice mDevice = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        mDevice.pressBack();

        try {
            Thread.sleep(450);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        onView(withId(R.id.submitButton)).perform(click());

        try {
            Thread.sleep(450);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @After
    public void tearDown() throws Exception {
        //After Test case Execution
    }
}