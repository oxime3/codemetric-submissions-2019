package cucumber.runtime.android.stub.wanted;

public class R {

    public static class SomeInnerClass {

    }
}
