package cucumber.runtime.android.stub.unwanted;

public class SomeUnwantedClass {
}
