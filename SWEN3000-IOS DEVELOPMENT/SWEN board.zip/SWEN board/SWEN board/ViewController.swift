//
//  ViewController.swift
//  SWEN board
//
//  Created by Administrator on 14/05/2019.
//  Copyright © 2019 CodeMetric Technologies. All rights reserved.
//

import UIKit
import FirebaseAuth

class CreateBulletinViewPost: UIViewController {
    
    
    @IBOutlet weak var subjectTextField: UITextField!
    @IBOutlet weak var bodyTextField: UITextField!
  
    @IBAction func doneButtonTouched(_ sender: UIBarButtonItem) {
        guard
            let bulletinSubject = subjectTextField.text,
            let bulletinBody = bodyTextField.text else {
                return
        }
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MM-dd-yyyy HH:mm"
        let postDate = dateFormatter.string(from: NSDate() as Date)
        let author = "Scott"
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
//    func getUserInput(){
//
//    }
    
    


  
}

