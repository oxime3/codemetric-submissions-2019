//
//  SinglePostView.swift
//  SWEN board
//
//  Created by administrator on 2019/6/1.
//  Copyright © 2019 CodeMetric Technologies. All rights reserved.
//

import UIKit
import Foundation
import Firebase

class SinglePostView: UIViewController {
    
    
    @IBOutlet weak var titlE: UILabel!
    @IBOutlet weak var author: UILabel!
    @IBOutlet weak var date: UILabel!
    @IBOutlet weak var body: UILabel!
    
    
    
    var ref = DatabaseReference()
    //var handler = DatabaseHandle?
    var uid: String!
    var postAuthor: String!
    var postTitle: String!
    var postDate: String!
    var postBody: String!
    var postId: String!
    var postidreceived: String!
    weak var textField: UITextField!
    //weak var labelMessage: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
  /*
        // Do any additional setup after loading the view.
        //self.postidreceived = "-LgQg-KNPgK61o2IFrPg"
        ref = Database.database().reference(withPath: "bulletins")
        ref.child(postidreceived).observe(.value, with: { (snapshot) in
            
            if let dictionary = snapshot.value as? [String:Any] {
                
                self.titlE.text = dictionary["title"] as? String
                self.author.text = dictionary["author"] as? String
                self.date.text = dictionary["timeStamp"] as? String
                self.body.text = dictionary["body"] as? String
            }
        })
 */
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.postidreceived = "-LgQg-KNPgK61o2IFrPg"
        
        ref = Database.database().reference(withPath: "bulletins")
        ref.child(postidreceived).observe(.value, with: { (snapshot) in
            if let dictionary = snapshot.value as? [String:Any] {
                
                self.titlE.text = dictionary["title"] as? String
                self.author.text = dictionary["author"] as? String
                self.date.text = dictionary["timeStamp"] as? String
                self.body.text = dictionary["body"] as? String
            }
        })
    }
    
    @IBAction func shareButton(_ sender: UIBarButtonItem) {
        let activityController = UIActivityViewController(activityItems: [self.author!, self.titlE!, self.date!, self.body!], applicationActivities: nil)
        
        self.present(activityController, animated: true, completion: nil)
    }
    
    @IBAction func backButton(_ sender: UIBarButtonItem) {
    }
    
    
    @IBAction func deleteButton(_ sender: UIBarButtonItem) {
        
        let dialogMessage = UIAlertController(title: "Confirm Action", message: "Are you sure you wish to delete this bulletin?", preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "Yes", style: .default) { (_) in
            
            self.DeletePost(id: self.postId!)
        }
        
        let noAction = UIAlertAction(title: "Cancel", style: .cancel) { (_) in
            
            }
        
        dialogMessage.addAction(okAction)
        dialogMessage.addAction(noAction)
        
            present(dialogMessage, animated: true, completion: nil)
    }
    
    @IBAction func editButton(_ sender: UIBarButtonItem) {
        let alertController = UIAlertController(title: self.titlE.text!, message: "Do you wish to update post?", preferredStyle: .alert)
        
        let updateAction = UIAlertAction(title: "Edit body" , style: .default) { (_) in
            
            alertController.addTextField { (textfield) in
                textfield.text = self.body.text!
            }
            
            let newBody = alertController.textFields?[0].text
            
            self.UpdatePost(id: self.postidreceived, author: self.author.text!, body: newBody!, title: self.titlE.text!)
            
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { (_) in
            
        }
        
        alertController.addTextField {(textField) in
            textField.text = self.body.text!
        }
        
        alertController.addAction(updateAction)
        alertController.addAction(cancelAction)
        
        present(alertController, animated: true, completion: nil)
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
    
    func UpdatePost(id: String , author: String , body: String , title: String ){
        
        //        get new date
        let date = Date.init(timeIntervalSinceNow: 86400)
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .short
        dateFormatter.timeStyle = .short
        let dateString = dateFormatter.string(from: date)
        
                let post = [
                    "key": id,
                    "author" : author,
                    "body" : body,
                    "timeStamp" : dateString,
                    "title" : title
                ]
        
                self.ref.child(postidreceived).setValue(post)
                //labelMessage.text = "Post updated"
        
        self.date.text = dateString
        self.body.text = body
        
    }
    
    func DeletePost(id:String){
        
        self.ref.child(postidreceived).setValue(nil)
        //ref.database.reference().child("bulletins").child(postidreceived).setValue(nil)
        
        self.titlE.text = ""
        self.author.text = ""
        self.date.text = ""
        self.body.text = ""
        
    }
    
}



