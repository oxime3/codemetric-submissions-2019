//
//  Cell.swift
//  SWEN board
//
//  Created by Khadeja Clarke on 01/06/2019.
//  Copyright © 2019 CodeMetric Technologies. All rights reserved.
//

import UIKit

class Cell: UICollectionViewCell {
    @IBOutlet weak var imageView: UIImageView!
}

