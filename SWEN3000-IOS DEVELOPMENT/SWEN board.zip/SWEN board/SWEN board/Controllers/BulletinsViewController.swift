//
//  BulletinsViewController.swift
//  BulletinBoard
//
//  Created by Khadeja Clarke on 20/05/2019.
//  Copyright © 2019 Khadeja Clarke. All rights reserved.
//

import UIKit
import Firebase

final class BulletinsViewController: UICollectionViewController {
    // MARK: - Properties
    private let reuseIdentifier = "Bulletin"
    private let sectionInsets = UIEdgeInsets(top: 0.0, left: 20.0, bottom: 50.0, right: 20.0)
    private let itemsPerRow: CGFloat = 2
    private var bulletins: [Bulletin] = []
    private var ref = DatabaseReference()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "background")!)
        
        let fixedSpace = UIBarButtonItem(barButtonSystemItem: .fixedSpace, target: nil, action: nil)
        let flexibleSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let compose = UIBarButtonItem(barButtonSystemItem: .compose, target: self, action: #selector(composeButtonAction(_:)))
        compose.tintColor = UIColor.orange
        let items = [fixedSpace, flexibleSpace, compose, flexibleSpace, fixedSpace]
        
        self.navigationController?.isToolbarHidden = false
        self.setToolbarItems(items, animated: true)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        ref = Database.database().reference(withPath: "bulletins")
        ref.observe(DataEventType.value, with: { (snapshot) in
            if snapshot.childrenCount > 0 {
                self.bulletins.removeAll()
                
                for bulletins in snapshot.children.allObjects as! [DataSnapshot] {
                    let instance = bulletins.value as? [String: Any]
                    let author = instance?["author"]
                    let title = instance?["title"]
                    let body = instance?["body"]
                    let timeStamp = instance?["timeStamp"]
                    
                    let bulletin = Bulletin(author: (author as! String?)!,
                                            title: (title as! String?)!,
                                            body: (body as! String?)!,
                                            timeStamp: (timeStamp as! String?)!)
                    
                    self.bulletins.append(bulletin)
                }
                self.collectionView.reloadData()
            }
        })
    }
    
    @IBAction func composeButtonAction(_ sender: UIBarButtonItem) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let newViewController = storyBoard.instantiateViewController(withIdentifier: "CreateBulletinStoryBoard")
        self.present(newViewController, animated: true, completion: nil)
    }
}

// MARK: - Supporting Methods
private extension BulletinsViewController {
    func bulletin(for indexPath: IndexPath) -> Bulletin {
        return self.bulletins[indexPath.item]
    }
    
    func generateImageWithText(text: String) -> UIImage {
        let image = UIImage(named: "bulletin")!
        let imageView = UIImageView(image: image)
        imageView.backgroundColor = UIColor.clear
        imageView.frame = CGRect(x: 0, y: 0, width: image.size.width, height: image.size.height)
        
        let label = UILabel(frame: CGRect(x: 0, y: 0, width: image.size.width, height: image.size.height))
        label.backgroundColor = UIColor.clear
        label.font = UIFont.boldSystemFont(ofSize: 50.0)
        label.adjustsFontSizeToFitWidth = false
        label.lineBreakMode = .byWordWrapping
        label.textAlignment = .center
        label.textColor = UIColor.black
        label.text = text
        
        UIGraphicsBeginImageContextWithOptions(label.bounds.size, false, 0);
        imageView.layer.render(in: UIGraphicsGetCurrentContext()!)
        label.layer.render(in: UIGraphicsGetCurrentContext()!)
        let imageWithText = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext();
        
        return imageWithText
    }
}


// MARK: - Data Source
extension BulletinsViewController {
    override func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.bulletins.count
    }
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let item = bulletin(for: indexPath)
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath) as! Cell
        cell.backgroundColor = UIColor.clear
        cell.imageView.image = generateImageWithText(text: item.title)
        
        return cell
    }
    
    override func collectionView(_ collectionView: UICollectionView, performAction action: Selector, forItemAt indexPath: IndexPath, withSender sender: Any?) {

        let storyBoard: UIStoryboard = UIStoryboard(name: "SinglePostView", bundle: nil)
        let newViewController = storyBoard.instantiateViewController(withIdentifier: "singlepostview") as! SinglePostView
        newViewController.postidreceived = bulletin(for: indexPath).firebaseKey
        self.present(newViewController, animated: true, completion: nil)
   }
}

// MARK: - Flow Layout Delegate
extension BulletinsViewController : UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let paddingSpace = sectionInsets.left * (itemsPerRow + 1)
        let availableWidth = view.frame.width - paddingSpace
        let widthPerItem = availableWidth / itemsPerRow
        
        return CGSize(width: widthPerItem, height: widthPerItem)
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        insetForSectionAt section: Int) -> UIEdgeInsets {
        return sectionInsets
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return sectionInsets.left
    }
}

