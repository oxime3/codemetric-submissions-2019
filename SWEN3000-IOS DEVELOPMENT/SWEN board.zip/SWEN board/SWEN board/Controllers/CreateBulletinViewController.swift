//
//  ViewController.swift
//  SWEN board
//
//  Created by Administrator on 14/05/2019.
//  Copyright © 2019 CodeMetric Technologies. All rights reserved.
//

import UIKit
import Firebase


class CreateBulletinViewController: UIViewController {
    
    
    var mDatabaseRef = DatabaseReference()

    
    @IBOutlet weak var subjectTextField: UITextField!
   
  
    @IBOutlet weak var bodyTextField: UITextView!
    @IBOutlet weak var createPostNavBar: UINavigationItem!

    @IBAction func doneButtonTouched(_ sender: UIBarButtonItem) {
        guard
            let bulletinTitle = subjectTextField.text,
            let bulletinBody = bodyTextField.text else {
                UIAlertController(title: "Invalid", message: "Cannot create empty bulletin.", preferredStyle: .alert)
                return
        }
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MM-dd-yyyy HH:mm"
        let postDate = dateFormatter.string(from: NSDate() as Date)
        let author = Auth.auth().currentUser?.displayName
        
        let mBulletin = Bulletin(author: author!, title: bulletinTitle , body: bulletinBody, timeStamp: postDate)
        createAndPushBulletin(bulletin: mBulletin)
        
        let alert = UIAlertController(title: "Create Bulletin",
                                      message: "Successfully created.",
                                      preferredStyle: .alert)
        
        
        let saveAction = UIAlertAction(title: "OK", style: .default) { _ in}
        
        let cancelAction = UIAlertAction(title: "OK",
                                         style: .cancel){_ in
            self.bodyTextField.text = ""
            self.subjectTextField.text = ""
        }
        
            
//            alert.addAction(saveAction)
            alert.addAction(cancelAction)
            
            self.present(alert, animated: true, completion: nil)
        
    }
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
 
        mDatabaseRef = Database.database().reference(withPath: "bulletins")
        
    }
    
    func createAndPushBulletin(bulletin:Bulletin){
        var mBulletin = bulletin
        
        let mRef = mDatabaseRef.childByAutoId()
        let mKey = mRef.key!
        
        mBulletin.firebaseRef = mRef
        mBulletin.firebaseKey = mKey
        
        mRef.setValue(mBulletin.toAnyObject())
        
        
    }
    
    

}

