//
//  BulletinModel.swift
//  SWEN board
//
//  Created by Administrator on 01/06/2019.
//  Copyright © 2019 CodeMetric Technologies. All rights reserved.
//

import Foundation
import Firebase

struct Bulletin {
    let author:String
    let title:String
    let body:String
    let timeStamp:String
    
    var firebaseRef: DatabaseReference?
    var firebaseKey: String?
    
    init(author:String, title:String, body:String, timeStamp:String) {
        self.author = author
        self.title = title
        self.body = body
        self.timeStamp = timeStamp
        self.firebaseRef = nil
        self.firebaseKey = nil
    }
    
    init?(snapshot: DataSnapshot) {
        guard
            let value = snapshot.value as? [String: AnyObject],
            let author = value["author"] as? String,
            let title = value["title"] as? String,
            let body = value["body"] as? String,
            let timeStamp = value["timestamp"] as? String
        else {
            return nil
        }
        
        self.author = author
        self.title = title
        self.body = body
        self.timeStamp = timeStamp
        self.firebaseRef = snapshot.ref
        self.firebaseKey = snapshot.key
    }
    
    func toAnyObject() -> Any {
        return [
            "author": author,
            "title": title,
            "body": body,
            "timeStamp": timeStamp
        ]
    }
    
}
